# -*- coding: utf-8 -*-
"""
make_bimodal_tables.py -- summary tables of the bimodal samples (size ratios 2, 3, 5, 7 and 10; intensity splits 50/50, 80/20 and 20/80).

    python code/make_bimodal_tables.py

Reads the evaluated runs data/records/records_{main,i20,regalpha,cumtab}.csv (written by `run_study.py collect`). Writes
  results/2_bimodal/success_by_intensity_split.csv   resolution limits of D, NNLS and the regularized fit (alpha 0.05, 0.1, 0.2; all files and curated) for the
                                                     three intensity splits: runs, correct-count and success runs, median Rh error of the count-correct runs, per cell
  results/2_bimodal/method_combinations.csv          share of runs (first 10 replicates, identical data sets for the three methods D, NNLS, Reg) with
                                                     full_<m>   method m: correct number of populations and both radii within +-20 % of the truth ("full success")
                                                     both_<m>   method m: a found peak within +-20 % of each true radius (additional peaks ignored)
                                                     any_both   at least one method has both_<m>
                                                     two_methods each true population has a peak within +-20 % from at least two of the three methods
                                                     consensus  peaks confirmed by a peak of another method within +-20 % are merged; correct if exactly two peaks remain
                                                                and each lies within +-20 % of a true radius (true radii are used only for scoring)
                                                     (averages over the three methods: full_avg, both_avg)
  results/2_bimodal/decision_rules_flagged.csv       decision rules for runs flagged as multimodal by the cumulant fit (fitted PDI of C2 above 0.3), s = 1:
                                                     single method, average of the methods, oracle (best of the three), consensus, majority of the
                                                     number of populations; success = two populations, each radius within +-20 % of the true radius
Success = correct number of populations and every Rh within +-20 % of the truth, as everywhere in the study.
"""
import numpy as np
import pandas as pd

import paths as P

TOL = 0.2
RATIOS = (2.0, 3.0, 5.0, 7.0, 10.0)
METHODS = ("D", "NNLS", "Reg")
FLAG = 0.3


def near(a, b, tol=TOL):
    return abs(a / b - 1) <= tol


def group(vals, tol=TOL):
    """merge values within +-tol of the running mean of a group; geometric mean per group"""
    out = []
    for v in sorted(vals):
        if out and near(v, np.mean(out[-1]), tol):
            out[-1].append(v)
        else:
            out.append([v])
    return [float(np.exp(np.mean(np.log(g)))) for g in out]


def load_records():
    """bimodal runs of D, NNLS and Reg (main and 20/80 sets), first 10 replicates, size ratios 2 to 10"""
    d = pd.concat([pd.read_csv(P.records("main")), pd.read_csv(P.records("i20"))], ignore_index=True)
    d = d[d.method.isin(METHODS) & (d.rep < 10) & ~d.geometry.str.startswith("mono")]
    d = d.drop_duplicates(["key", "rep", "method"])
    d["ratio"] = pd.to_numeric(d.geometry.str.extract(r"_r([0-9.]+)_")[0])
    d["pdi_pop"] = pd.to_numeric(d.geometry.str.extract(r"pdi([0-9.]+)")[0])
    d["split"] = np.where(d.geometry.str.endswith("_i20"), "_i20", np.where(d.geometry.str.endswith("_i80"), "_i80", ""))
    d = d[d.ratio.isin(RATIOS) & ~d.geometry.str.contains("_rh")]
    # a failed fit (one NNLS run: LinAlgError) counts as a failure
    d["count_ok"] = d.count_ok.astype(float).fillna(0.0)
    d["success"] = d.success.astype(float).fillna(0.0)
    return d


def runs_by_key(d):
    runs = {}
    for r in d.itertuples(index=False):
        peaks = [getattr(r, f"rh_{k}") for k in (1, 2, 3, 4) if np.isfinite(getattr(r, f"rh_{k}"))]
        runs.setdefault((r.geometry, r.noise_level, r.rep), {})[r.method] = dict(
            peaks=sorted(peaks), truth=sorted([r.rh_true_1, r.rh_true_2]), ratio=r.ratio, pdi=r.pdi_pop, success=float(r.success))
    return runs


# ----------------------------------------------------------------------------- success_by_intensity_split.csv
FRAC_METHODS = ["D", "D:gap=3", "NNLS", "Reg:alpha=0.2", "Reg:alpha=0.2-cur", "Reg:alpha=0.1", "Reg:alpha=0.1-cur",
                "Reg:alpha=0.05", "Reg:alpha=0.05-cur"]
FRAC = {"": "50/50", "_i80": "80/20", "_i20": "20/80"}


def success_by_intensity_split():
    d = pd.concat([pd.read_csv(P.records(n)) for n in ("main", "regalpha", "i20")], ignore_index=True)
    d["method"] = d.method.replace({"Reg": "Reg:alpha=0.2", "Reg-cur": "Reg:alpha=0.2-cur"})
    d = d[d.method.isin(FRAC_METHODS) & ~d.geometry.str.startswith("mono")].copy()
    d["pdi"] = d.geometry.str.extract(r"pdi([0-9.]+)")[0].astype(float)
    d["ratio"] = d.geometry.str.extract(r"_r([0-9.]+)_")[0].astype(float)
    d["frac"] = d.geometry.map(lambda g: FRAC["_i80" if g.endswith("_i80") else "_i20" if g.endswith("_i20") else ""])
    d = d.drop_duplicates(subset=["key", "rep", "method"])
    rows = []
    for (fr, m, pdi, lv, ratio), g in d.groupby(["frac", "method", "pdi", "noise_level", "ratio"]):
        ok = g[g.count_ok.astype(bool)]
        rows.append({"frac": fr, "method": m, "pdi": pdi, "noise_level": lv, "ratio": ratio, "n": len(g),
                     "count_ok": int(g.count_ok.astype(bool).sum()), "success": int(g.success.astype(bool).sum()),
                     "err_small_median_pct": 100 * ok.rel_err_1.median() if len(ok) else np.nan,
                     "err_large_median_pct": 100 * ok.rel_err_2.median() if len(ok) else np.nan})
    c = pd.DataFrame(rows)
    c["rate"] = c.count_ok / c.n
    c["srate"] = c.success / c.n
    return c


# ----------------------------------------------------------------------------- method_combinations.csv
def combination_runs():
    runs = runs_by_key(load_records())
    rows = []
    for (geom, level, rep), mm in runs.items():
        if len(mm) < len(METHODS):
            continue
        truth = mm["D"]["truth"]
        row = dict(geometry=geom, noise_level=level, rep=rep, ratio=mm["D"]["ratio"], pdi=mm["D"]["pdi"])
        got = {}
        for m in METHODS:
            got[m] = [any(near(p, t) for p in mm[m]["peaks"]) for t in truth]
            row[f"full_{m}"] = mm[m]["success"]
            row[f"both_{m}"] = float(all(got[m]))
        row["full_avg"] = np.mean([row[f"full_{m}"] for m in METHODS])
        row["both_avg"] = np.mean([row[f"both_{m}"] for m in METHODS])
        row["any_both"] = float(any(all(got[m]) for m in METHODS))
        row["two_methods"] = float(all(sum(got[m][k] for m in METHODS) >= 2 for k in range(2)))
        confirmed = [p for m in METHODS for p in mm[m]["peaks"] if any(near(p, q) for o in METHODS if o != m for q in mm[o]["peaks"])]
        cons = group(confirmed)
        row["consensus"] = float(len(cons) == 2 and all(any(near(c, t) for c in cons) for t in truth)
                                 and all(any(near(c, t) for t in truth) for c in cons))
        rows.append(row)
    return pd.DataFrame(rows)


def method_combinations():
    t = combination_runs()
    cols = [f"full_{m}" for m in METHODS] + ["full_avg"] + [f"both_{m}" for m in METHODS] + ["both_avg", "any_both", "two_methods", "consensus"]
    allr = t.groupby(["pdi", "noise_level"])[cols].mean()
    allr["runs_per_method"] = t.groupby(["pdi", "noise_level"]).size()
    byr = t.groupby(["pdi", "noise_level", "ratio"])[cols].mean().reset_index()
    allr = allr.reset_index().assign(ratio="all")
    return pd.concat([allr, byr], ignore_index=True)


# ----------------------------------------------------------------------------- decision_rules_flagged.csv
def correct(peaks, truth):
    return len(peaks) == 2 and all(near(p, t) for p, t in zip(sorted(peaks), truth))


def flagged_runs():
    runs = runs_by_key(load_records())
    c = pd.read_csv(P.records("cumtab"), low_memory=False)
    c = c[(c.method == "C2") & ~c.geometry.str.startswith("mono")]
    c = c.drop_duplicates(["geometry", "noise_level", "rep"]).set_index(["geometry", "noise_level", "rep"]).pdi      # fitted PDI of C2
    rows = []
    for key, mm in runs.items():
        if len(mm) < len(METHODS) or key not in c.index:
            continue
        truth = mm["D"]["truth"]
        row = dict(geometry=key[0], noise_level=key[1], rep=key[2], ratio=mm["D"]["ratio"], pdi=mm["D"]["pdi"], flagged=bool(c[key] > FLAG))
        for m in METHODS:
            row[f"single_{m}"] = mm[m]["success"]
        row["single_avg"] = np.mean([row[f"single_{m}"] for m in METHODS])
        row["oracle"] = float(max(row[f"single_{m}"] for m in METHODS) > 0)
        confirmed = [p for m in METHODS for p in mm[m]["peaks"] if any(near(p, q) for o in METHODS if o != m for q in mm[o]["peaks"])]
        cons = group(confirmed)
        row["consensus_answer"] = float(len(cons) == 2)
        row["consensus"] = float(correct(cons, truth))
        counts = [len(mm[m]["peaks"]) for m in METHODS]
        modal = max(set(counts), key=counts.count)
        if counts.count(modal) >= 2:
            maj = [m for m in METHODS if len(mm[m]["peaks"]) == modal]
            res = [float(np.exp(np.mean(np.log([mm[m]["peaks"][j] for m in maj])))) for j in range(modal)] if modal > 0 else []
            row["majority_answer"] = 1.0
            row["majority"] = float(correct(res, truth))
        else:
            row["majority_answer"], row["majority"] = 0.0, 0.0
        rows.append(row)
    return pd.DataFrame(rows)


def summarize(x):
    s = {"runs": len(x)}
    for k in ("single_D", "single_NNLS", "single_Reg", "single_avg", "oracle", "consensus", "majority"):
        s[k] = 100 * x[k].mean()
    for k in ("consensus", "majority"):
        a = x[x[f"{k}_answer"] > 0]
        s[f"{k}_answered"] = 100 * x[f"{k}_answer"].mean()
        s[f"{k}_correct_if_answered"] = 100 * a[k].mean() if len(a) else np.nan
    return pd.Series(s)


def decision_rules_flagged():
    t = flagged_runs()
    out = []
    for pdi in (0.1, None):
        for flagged in (None, True, False):
            x = t[(t.noise_level == 1)]
            if pdi is not None:
                x = x[x.pdi == pdi]
            if flagged is not None:
                x = x[x.flagged == flagged]
            r = summarize(x)
            r["pdi"] = "all" if pdi is None else pdi
            r["subset"] = {None: "all runs", True: "flagged (C2 PDI > 0.3)", False: "not flagged"}[flagged]
            out.append(r)
    return pd.DataFrame(out)


def main():
    success_by_intensity_split().to_csv(P.table("2_bimodal", "success_by_intensity_split.csv"), index=False)
    method_combinations().to_csv(P.table("2_bimodal", "method_combinations.csv"), index=False)
    res = decision_rules_flagged()
    res.to_csv(P.table("2_bimodal", "decision_rules_flagged.csv"), index=False)
    pd.set_option("display.width", 220)
    print(res.set_index(["pdi", "subset"]).round(0).T.to_string())


if __name__ == "__main__":
    main()
