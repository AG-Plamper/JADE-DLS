# -*- coding: utf-8 -*-
"""
check_noise_model_gold.py -- back-check of the raw 30 nm + 200 nm gold mixture against the assumptions of the synthetic study.

    python code/check_noise_model_gold.py [--dir "goldparticle-references-rawdata/30nm+200nm"] [--analyse]

Reads the .ASC files (read-only; the three single runs per angle, not the averaged files) and reports
  * coherence factor beta (first channels) and the baseline (mean of the last lag channels),
  * count rates and the difference between the two detector correlations (columns 1 and 2),
  * the empirical noise level against the Biganzoli-Ferri model (s = sd over the three runs / sigma_BF, by lag band)
    and the lag-to-lag correlation of the residuals,
  * with --analyse: Method D, NNLS and the regularised fit on the real files with the pipeline of the study
    (weighted, notebook defaults), peaks per angle.
Writes results/6_noise_model_check/descriptive.csv, noise_level.csv, lag_correlation.csv (--analyse additionally method_<setting>.csv, one per method setting).
"""
import argparse
import glob
import os
import re
import sys
import warnings
from pathlib import Path

os.environ["MPLBACKEND"] = "Agg"
HERE = Path(__file__).resolve().parent
import paths as P  # noqa: E402  (locations of data, results, ...)
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(P.ROOT))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

import preprocessing as pp  # noqa: E402
import simulate_data  # noqa: E402
import weighting as wt  # noqa: E402

warnings.simplefilter("ignore")
BANDS = [(1e-5, 1e-4), (1e-4, 1e-3), (1e-3, 1e-2), (1e-2, 1e-1), (1e-1, 1.0), (1.0, 10.0)]


def load(folder):
    files = sorted(f for f in glob.glob(str(Path(folder) / "*.ASC")) if "averaged" not in f)
    corr, base = {}, []
    for f in files:
        c = pp.extract_correlation(f)
        d = pp.extract_data(f)
        if c is None or d is None:
            continue
        name = Path(f).name
        corr[name] = pd.DataFrame({"time [ms]": c[0].values * 1e3 / 1e3, "correlation 1": c[1].values,
                                   "correlation 2": c[2].values, "correlation 3": 0.0, "correlation 4": 0.0})
        row = d.iloc[0].to_dict()
        row["filename"] = name
        base.append(row)
    base = pd.DataFrame(base)
    base.columns = [re.sub(r"angle \[.*\]", "angle [°]", c) for c in base.columns]
    base["q"] = abs(4 * np.pi * base["refractive_index"] / base["wavelength [nm]"]
                    * np.sin(np.radians(base["angle [°]"]) / 2))
    base["q^2"] = base["q"] ** 2
    base.index = base.index + 1
    return corr, base


def descriptive(corr, base):
    rows = []
    for name, df in corr.items():
        b = base[base.filename == name].iloc[0]
        y1, y2 = df["correlation 1"].values, df["correlation 2"].values
        y = (y1 + y2) / 2
        rows.append({"file": name, "angle": b["angle [°]"], "T_K": b["temperature [K]"],
                     "cr0_kHz": b["meancr0 [kHz]"], "cr1_kHz": b["meancr1 [kHz]"],
                     "beta_first5": float(np.mean(y[:5])), "baseline_last20": float(np.mean(y[-20:])),
                     "baseline_last20_sd": float(np.std(y[-20:], ddof=1)),
                     "sd_col1_minus_col2_first50": float(np.std((y1 - y2)[:50], ddof=1)),
                     "sd_col1_minus_col2_last50": float(np.std((y1 - y2)[-50:], ddof=1))})
    return pd.DataFrame(rows)


def noise_calibration(corr, base):
    tau = simulate_data.LAG_GRID_S
    out, lagcorr = [], []
    by_angle = base.groupby("angle [°]")
    for ang, g in by_angle:
        names = list(g.filename)
        if len(names) < 3:
            continue
        Y = np.array([(corr[n]["correlation 1"].values + corr[n]["correlation 2"].values) / 2 for n in names])
        mean = Y.mean(axis=0)
        resid = Y - mean
        sd_emp = np.sqrt((resid ** 2).sum(axis=0) / (len(names) - 1))
        beta = float(np.mean(mean[:5]))
        cr = float(g[["meancr0 [kHz]", "meancr1 [kHz]"]].values.mean())
        try:
            _, tau_c, _ = wt.prefit_single_exponential(tau, np.clip(mean, 1e-6, None))
            _, diag = wt.estimate_weights(tau, np.clip(mean, 1e-6, None), cr, cr, 12.0, beta=beta, tau_c=tau_c,
                                          return_diagnostics=True, verbose=False)
            sd_bf = np.sqrt(diag["sigma2"])
        except Exception as e:
            print("BF failed for", ang, e)
            continue
        for lo, hi in BANDS:
            m = (tau >= lo) & (tau < hi)
            if m.sum() < 5:
                continue
            ratio = np.sqrt(np.mean(sd_emp[m] ** 2) / np.mean(sd_bf[m] ** 2))     # rms ratio, unbiased in variance
            out.append({"angle": ang, "lag_lo": lo, "lag_hi": hi, "n_channels": int(m.sum()),
                        "s_eff": ratio, "tau_c_ms": tau_c * 1e3, "cr_kHz": cr})
        # lag-to-lag correlation of the standardised residuals (rows pooled over the 3 runs)
        z = resid / np.where(sd_emp > 0, sd_emp, np.nan)
        for lo, hi in BANDS:
            idx = np.where((tau >= lo) & (tau < hi))[0]
            idx = idx[idx > 0]
            if len(idx) < 5:
                continue
            a = np.concatenate([resid[k, idx[:-1]] for k in range(len(names))])
            b = np.concatenate([resid[k, idx[1:]] for k in range(len(names))])
            lagcorr.append({"angle": ang, "lag_lo": lo, "lag_hi": hi, "lag1_corr": float(np.corrcoef(a, b)[0, 1])})
    return pd.DataFrame(out), pd.DataFrame(lagcorr)


def analyse(corr, base):
    import analysis_pipeline as pl
    drop = ["time [ms]", "correlation 1", "correlation 2", "correlation 3", "correlation 4"]
    pc = pp.process_correlation_data(corr, drop)
    s = pl.Settings()
    res = pl.analyze(pc, base, s, ("D", "D:gap=3", "NNLS", "Reg", "Reg:alpha=0.05", "Reg:alpha=0.1"))
    rows = []
    for m, r in res.items():
        rows.append({"method": m, "n_found": r["n_found"], "rh": [round(x, 1) for x in r["rh"]],
                     "abundance": [round(x, 2) if x == x else None for x in r["abundance"]], "error": r["error"]})
        tab = r.get("table")
        if tab:
            t = pd.DataFrame(tab)
            ncol = [c for c in t.columns if c.startswith("gamma_") and c != "gamma_mean"]
            t["n_peaks"] = t[ncol].notna().sum(axis=1)
            t.to_csv(P.table("6_noise_model_check", f"method_{m.replace(':', '_').replace('=', '')}.csv"), index=False)
    return pd.DataFrame(rows), res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default=str(P.ROOT / "goldparticle-references-rawdata" / "30nm+200nm"))
    ap.add_argument("--analyse", action="store_true")
    a = ap.parse_args()
    pd.set_option("display.width", 250)
    pd.set_option("display.max_columns", 30)
    pd.set_option("display.max_rows", 200)
    corr, base = load(a.dir)
    print(len(corr), "files,", base["angle [°]"].nunique(), "angles")
    d = descriptive(corr, base)
    d.to_csv(P.table("6_noise_model_check", "descriptive.csv"), index=False)
    g = d.groupby("angle").agg(beta=("beta_first5", "mean"), baseline=("baseline_last20", "mean"),
                               baseline_sd=("baseline_last20_sd", "mean"), cr0=("cr0_kHz", "mean"),
                               cr1=("cr1_kHz", "mean"), d_first=("sd_col1_minus_col2_first50", "mean"),
                               d_last=("sd_col1_minus_col2_last50", "mean"))
    print("\n== per angle (mean over the three runs)")
    print(g.round(5).to_string())
    nc, lc = noise_calibration(corr, base)
    nc.to_csv(P.table("6_noise_model_check", "noise_level.csv"), index=False)
    lc.to_csv(P.table("6_noise_model_check", "lag_correlation.csv"), index=False)
    print("\n== empirical noise / BF model (s_eff = rms ratio), median over angles by lag band")
    print(nc.groupby(["lag_lo", "lag_hi"]).s_eff.agg(["median", "min", "max"]).round(2).to_string())
    print("\n== lag-1 correlation of residuals, median over angles by lag band (synthetic model: 0.8-0.97 up to tau_c, 0 beyond ~300 tau_c)")
    print(lc.groupby(["lag_lo", "lag_hi"]).lag1_corr.agg(["median", "min", "max"]).round(2).to_string())
    if a.analyse:
        tab, res = analyse(corr, base)
        print("\n== methods on the real files (weighted, notebook defaults)")
        print(tab.to_string(index=False))


if __name__ == "__main__":
    main()
