# -*- coding: utf-8 -*-
"""
evaluate_runs.py
===========
Collect the per-task JSON files written by run_study.py into flat tables and summarise them
(success / count / spurious rates with Wilson intervals, Rh bias and spread, PDI).
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd


def collect(raw_dir):
    """One row per (task, method)."""
    rows = []
    for f in sorted(Path(raw_dir).rglob("*.json")):
        t = json.loads(f.read_text(encoding="utf-8"))
        tr = t["truth"]
        for m, res in t["results"].items():
            ev = t["eval"][m]
            row = {
                "key": t["key"], "geometry": t["geometry"], "noise_level": t["noise_level"],
                "noise_mode": t["noise_mode"], "rep": t["rep"], "weighted": t["weighted"],
                "group": t["group"], "seconds": t["seconds"],
                # method B of the first runs regressed through the origin; relabelled so that 'B' is the free-intercept fit
                "method": "B-origin" if m == "B" and (t.get("settings") or {}).get("b_through_origin") else m,
                "n_found": res["n_found"], "pdi": res["pdi"], "error": res["error"],
                "n_true": tr["n_pop"], "rh_z": tr["rh_z"], "pdi_mix": tr["pdi_mix"],
                "count_ok": ev["count_ok"], "success": ev["success"], "spurious": ev["spurious"],
                "rel_err_z": ev["rel_err_z"],
            }
            for i in range(4):
                row[f"rh_{i + 1}"] = res["rh"][i] if i < len(res["rh"]) else np.nan
                row[f"abund_{i + 1}"] = res["abundance"][i] if i < len(res["abundance"]) else np.nan
                row[f"rh_true_{i + 1}"] = tr["rh_pops"][i] if i < len(tr["rh_pops"]) else np.nan
                row[f"rel_err_{i + 1}"] = ev["rel_err"][i] if i < len(ev["rel_err"]) else np.nan
            for k, v in (res.get("extra") or {}).items():
                row[f"x_{k}"] = v
            rows.append(row)
    return pd.DataFrame(rows)


def wilson(k, n, z=1.96):
    if n == 0:
        return (np.nan, np.nan)
    p = k / n
    d = 1 + z ** 2 / n
    c = (p + z ** 2 / (2 * n)) / d
    h = z * np.sqrt(p * (1 - p) / n + z ** 2 / (4 * n ** 2)) / d
    return (c - h, c + h)


def summarize(df, by=("geometry", "noise_level", "noise_mode", "weighted", "method")):
    """Rates are over runs that produced a result; failed runs count as failures of success/count_ok."""
    out = []
    for key, g in df.groupby(list(by), dropna=False):
        n = len(g)
        ok = g["error"].isna() & g["n_found"].notna()
        succ = int(g["success"].fillna(False).astype(bool).sum())
        cnt = int(g["count_ok"].fillna(False).astype(bool).sum())
        spu = int(g["spurious"].fillna(False).astype(bool).sum())
        lo, hi = wilson(succ, n)
        row = dict(zip(by, key))
        row.update({
            "n_runs": n, "n_failed": int((~ok).sum()),
            "success": succ / n, "success_lo": lo, "success_hi": hi,
            "count_ok": cnt / n, "spurious": spu / n,
            "n_found_mean": g["n_found"].mean(),
            "n_true": g["n_true"].iloc[0],
        })
        for i in (1, 2):
            e = g[f"rel_err_{i}"].dropna()
            row[f"rh{i}_true"] = g[f"rh_true_{i}"].iloc[0]
            row[f"rh{i}_mean"] = g[f"rh_{i}"].mean()
            row[f"rh{i}_sd"] = g[f"rh_{i}"].std()
            row[f"rh{i}_bias_pct"] = 100 * e.mean() if len(e) else np.nan
        z = g["rel_err_z"].dropna()
        row["rh_z_bias_pct"] = 100 * z.mean() if len(z) else np.nan
        row["rh_z_sd_pct"] = 100 * z.std() if len(z) > 1 else np.nan
        row["pdi_mean"] = g["pdi"].mean()
        row["pdi_sd"] = g["pdi"].std()
        row["pdi_true_mix"] = g["pdi_mix"].iloc[0]
        row["seconds_mean"] = g["seconds"].mean()
        out.append(row)
    return pd.DataFrame(out)
