# -*- coding: utf-8 -*-
"""
sweep_clustering_trimodal.py -- cross-file clustering parameters on the stored per-file tables of the trimodal samples (see sweep_clustering.py).

    python code/sweep_clustering_trimodal.py [--jobs 14] [--levels 1 2 0] [--methods D NNLS Reg]

No refit: the per-file fit tables stored in data/raw/tri (default settings of D, NNLS and the regularized fit) are clustered again for the
distance thresholds 0.5 to 4 and the minimum abundances 0.1, 0.3, 0.5 (strategy 'silhouette_refined') and scored against the stored truth.
Writes results/5_clustering_sensitivity/trimodal_runs_<method>.csv (one row per data set and setting) and trimodal.csv (pooled).
"""
import argparse
import contextlib
import io
import json
import os
import sys
import warnings
from pathlib import Path

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "1")
os.environ["MPLBACKEND"] = "Agg"
HERE = Path(__file__).resolve().parent
import paths as P  # noqa: E402  (locations of data, results, ...)
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(P.ROOT))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

RAW = P.RAW / "tri"
DISTANCES = (0.5, 1.0, 1.5, 2.0, 3.0, 4.0)
MIN_ABUNDANCES = (0.1, 0.3, 0.5)
GRID = [(d, m, "silhouette_refined") for d in DISTANCES for m in MIN_ABUNDANCES]
GEOMS = [f"tri_r{r}_pdi{p}{s}" for r in ("2", "3", "5") for p in ("0.05", "0.1", "0.2") for s in ("", "_i50", "_i17")]
KEY = {0: "s0_white", 1: "s1_correlated", 2: "s2_correlated"}
METHODS = ("D", "NNLS", "Reg")


def one(label, geom, level, rep):
    warnings.simplefilter("ignore")
    import analysis_pipeline as pl
    import simulate_data
    p = RAW / f"{geom}__{KEY[level]}_r{rep:03d}_{label}_w.json"
    if not p.exists():
        return []
    r = json.loads(p.read_text(encoding="utf-8"))
    res0 = r["results"].get(label)
    if not res0 or not res0.get("table"):
        return []
    c = pl.c_constant(simulate_data.simulate([(50.0, 0.05, 1.0)], noise_level=0, seed=0).df_basedata)
    out = []
    for dist, ma, strat in GRID:
        s = pl.Settings(cluster_distance=dist, cluster_min_abundance=ma, cluster_strategy=strat)
        rec = {"method": label, "geometry": geom, "level": level, "rep": rep, "distance": dist, "min_abundance": ma, "strategy": strat}
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                res = pl.cluster_from_table(label, res0["table"], c, s, curated=False)
            ev = pl.evaluate(res, r["truth"])
            rec.update(n_found=res["n_found"], count_ok=bool(ev["count_ok"]), success=bool(ev["success"]),
                       rh="; ".join(f"{x:.1f}" for x in res["rh"]))
        except Exception as e:
            rec.update(n_found=np.nan, count_ok=False, success=False, rh="", error=f"{type(e).__name__}: {e}")
        out.append(rec)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=14)
    ap.add_argument("--levels", nargs="*", type=int, default=[1, 2, 0])
    ap.add_argument("--methods", nargs="*", default=list(METHODS), choices=list(METHODS))
    a = ap.parse_args()
    from joblib import Parallel, delayed
    parts = []
    for label in a.methods:
        out = P.table("5_clustering_sensitivity", f"trimodal_runs_{label}.csv")
        if out.exists():
            print(label, "exists - skipped", flush=True)
            parts.append(pd.read_csv(out))
            continue
        tasks = [(label, g, lv, rep) for g in GEOMS for lv in a.levels for rep in ([0] if lv == 0 else range(10))]
        print(f"=== {label}: {len(tasks)} data sets x {len(GRID)} settings", flush=True)
        res = Parallel(n_jobs=a.jobs, batch_size=4, verbose=2)(delayed(one)(*t) for t in tasks)
        df = pd.DataFrame([x for r in res for x in r])
        df.to_csv(out, index=False)
        print(label, "->", out.name, len(df), "rows; errors:", int(df["error"].notna().sum()) if "error" in df else 0, flush=True)
        parts.append(df)
    d = pd.concat(parts, ignore_index=True)
    summ = (d.groupby(["method", "level", "distance", "min_abundance"])
            .agg(n=("success", "size"), count_ok=("count_ok", "mean"), success=("success", "mean")).reset_index())
    summ.to_csv(P.table("5_clustering_sensitivity", "trimodal.csv"), index=False)
    print("summary written", len(summ), "rows")


if __name__ == "__main__":
    main()
