# -*- coding: utf-8 -*-
"""
make_trimodal_tables.py -- summary tables of the trimodal samples.

    python code/make_trimodal_tables.py

Samples: Rh = 50/r, 50 and 50 r nm (neighbour ratio r = 2, 3, 5), PDI 0.05 / 0.1 / 0.2, intensity splits (small / middle / large) 33/33/33, 50/33/17 and 17/33/50;
s = 0 (1 data set), 1 and 2 (10 replicates); Method D, NNLS and the regularized fit at their default settings. Success = three populations and all Rh within +-20 %.
Writes
  results/3_trimodal/success_by_sample.csv        per sample, method and noise level: count-correct and success rate, recovery of each true population (a found
                                                  peak within +-20 % of its true Rh), distribution of the number of populations found
                                                  (read from data/raw/tri)
  results/3_trimodal/summary.csv                  the same pooled over the PDI: neighbour ratio x intensity split x method, s = 1 and 2
  results/3_trimodal/decision_rules_flagged.csv   decision rules for runs flagged as multimodal by the cumulant fit (fitted PDI of C2 above 0.3; from
                                                  data/records/records_tri.csv): single method, average of the three methods, oracle (at least one method
                                                  fully successful), consensus (peaks confirmed by another method within +-20 %), majority (number of populations on
                                                  which at least two methods agree, radii averaged over these methods); the true radii are used only for scoring
"""
import json

import numpy as np
import pandas as pd

import paths as P

RAW = P.RAW / "tri"
RATIOS = (2.0, 3.0, 5.0)
PDIS = (0.05, 0.1, 0.2)
SPLITS = [("33/33/33", ""), ("50/33/17", "_i50"), ("17/33/50", "_i17")]
METHODS = ("D", "NNLS", "Reg")
KEY = {0: "s0_white", 1: "s1_correlated", 2: "s2_correlated"}
TOL = 0.20
FLAG = 0.3


# ----------------------------------------------------------------------------- success_by_sample.csv, summary.csv
def load_runs(geom, level, method):
    out = []
    for rep in ([0] if level == 0 else range(10)):
        p = RAW / f"{geom}__{KEY[level]}_r{rep:03d}_{method}_w.json"
        if not p.exists():
            continue
        r = json.loads(p.read_text(encoding="utf-8"))
        res, ev = r["results"].get(method), r["eval"].get(method)
        t = r["truth"]["rh_pops"]
        if not res or res.get("error") or ev is None:
            out.append(dict(rh=[], n=0, count_ok=False, success=False, rec=[False] * 3, truth=t))
            continue
        rh = sorted(res["rh"])
        rec = [any(abs(v / tv - 1) <= TOL for v in rh) for tv in t]
        out.append(dict(rh=rh, n=len(rh), count_ok=bool(ev["count_ok"]), success=bool(ev["success"]), rec=rec, truth=t))
    return out


def success_by_sample():
    rows = []
    for suf_name, suf in SPLITS:
        for r in RATIOS:
            for pdi in PDIS:
                geom = f"tri_r{r:g}_pdi{pdi:g}{suf}"
                for level in (0, 1, 2):
                    for m in METHODS:
                        runs = load_runs(geom, level, m)
                        if not runs:
                            continue
                        rows.append(dict(geometry=geom, ratio=r, pdi=pdi, split=suf_name, level=level, method=m, n=len(runs),
                                         count_ok=np.mean([q["count_ok"] for q in runs]), success=np.mean([q["success"] for q in runs]),
                                         rec_small=np.mean([q["rec"][0] for q in runs]), rec_mid=np.mean([q["rec"][1] for q in runs]),
                                         rec_large=np.mean([q["rec"][2] for q in runs]),
                                         n_found_mean=np.mean([q["n"] for q in runs]),
                                         frac_n1=np.mean([q["n"] == 1 for q in runs]), frac_n2=np.mean([q["n"] == 2 for q in runs]),
                                         frac_n3=np.mean([q["n"] == 3 for q in runs]), frac_n4p=np.mean([q["n"] >= 4 for q in runs])))
    return pd.DataFrame(rows)


def summary(c):
    rows = []
    for level in (1, 2):
        for (r, name), g in c[c.level == level].groupby(["ratio", "split"]):
            row = dict(level=level, ratio=r, split=name)
            for m in METHODS:
                x = g[g.method == m]
                if len(x):
                    row[f"{m}_count"] = round(float(np.average(x.count_ok, weights=x.n)), 2)
                    row[f"{m}_success"] = round(float(np.average(x.success, weights=x.n)), 2)
                    row[f"{m}_pops_recovered"] = round(float(np.average((x.rec_small + x.rec_mid + x.rec_large) / 3, weights=x.n)), 2)
            rows.append(row)
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------------- decision_rules_flagged.csv
def near(a, b, tol=TOL):
    return abs(a / b - 1) <= tol


def group(vals):
    out = []
    for v in sorted(vals):
        if out and near(v, np.mean(out[-1])):
            out[-1].append(v)
        else:
            out.append([v])
    return [float(np.exp(np.mean(np.log(g)))) for g in out]


def correct(peaks, truth):
    return len(peaks) == len(truth) and all(near(p, t) for p, t in zip(sorted(peaks), truth))


def flagged_runs():
    d = pd.read_csv(P.records("tri"), low_memory=False)
    c = d[d.method == "C2"].drop_duplicates(["geometry", "noise_level", "rep"]).set_index(["geometry", "noise_level", "rep"]).pdi   # fitted PDI of C2
    d = d[d.method.isin(METHODS) & (d.rep < 10)].drop_duplicates(["key", "rep", "method"])
    runs = {}
    for r in d.itertuples(index=False):
        peaks = [] if (isinstance(r.error, str)) else [getattr(r, f"rh_{k}") for k in (1, 2, 3, 4) if np.isfinite(getattr(r, f"rh_{k}"))]
        truth = sorted(getattr(r, f"rh_true_{k}") for k in (1, 2, 3) if np.isfinite(getattr(r, f"rh_true_{k}")))
        runs.setdefault((r.geometry, r.noise_level, r.rep), {})[r.method] = dict(peaks=sorted(peaks), truth=truth, success=float(r.success) if r.success == r.success else 0.0)
    rows = []
    for key, mm in runs.items():
        if len(mm) < len(METHODS) or key not in c.index:
            continue
        truth = mm["D"]["truth"]
        pdi = float(key[0].split("_pdi")[1].split("_")[0])
        row = dict(geometry=key[0], noise_level=key[1], rep=key[2], pdi=pdi, flagged=bool(c[key] > FLAG))
        for m in METHODS:
            row[f"single_{m}"] = mm[m]["success"]
        row["single_avg"] = np.mean([row[f"single_{m}"] for m in METHODS])
        row["oracle"] = float(max(row[f"single_{m}"] for m in METHODS) > 0)
        confirmed = [p for m in METHODS for p in mm[m]["peaks"] if any(near(p, q) for o in METHODS if o != m for q in mm[o]["peaks"])]
        row["consensus"] = float(correct(group(confirmed), truth))
        counts = [len(mm[m]["peaks"]) for m in METHODS]
        modal = max(set(counts), key=counts.count)
        if counts.count(modal) >= 2 and modal > 0:
            maj = [m for m in METHODS if len(mm[m]["peaks"]) == modal]
            res = [float(np.exp(np.mean(np.log([mm[m]["peaks"][j] for m in maj])))) for j in range(modal)]
            row["majority_answer"], row["majority"] = 1.0, float(correct(res, truth))
        else:
            row["majority_answer"], row["majority"] = 0.0, 0.0
        rows.append(row)
    return pd.DataFrame(rows)


def summarize(x):
    s = {"runs": len(x)}
    for k in ("single_D", "single_NNLS", "single_Reg", "single_avg", "oracle", "consensus", "majority"):
        s[k] = 100 * x[k].mean()
    a = x[x.majority_answer > 0]
    s["majority_answered"] = 100 * x.majority_answer.mean()
    s["majority_correct_if_answered"] = 100 * a.majority.mean() if len(a) else np.nan
    return pd.Series(s)


def decision_rules_flagged():
    t = flagged_runs()
    out = []
    for level in (1.0, 2.0, 0.0):
        for pdi in (0.1, None):
            for flagged in (None, True):
                x = t[t.noise_level == level]
                if pdi is not None:
                    x = x[x.pdi == pdi]
                if flagged:
                    x = x[x.flagged]
                r = summarize(x)
                r["noise_level"], r["pdi"] = level, ("all" if pdi is None else pdi)
                r["subset"] = "flagged" if flagged else "all runs"
                out.append(r)
    return pd.DataFrame(out)


def main():
    c = success_by_sample()
    c.to_csv(P.table("3_trimodal", "success_by_sample.csv"), index=False)
    t = summary(c)
    t.to_csv(P.table("3_trimodal", "summary.csv"), index=False)
    pd.set_option("display.width", 250)
    print(t.to_string(index=False))
    res = decision_rules_flagged()
    res.to_csv(P.table("3_trimodal", "decision_rules_flagged.csv"), index=False)
    print(res.set_index(["noise_level", "pdi", "subset"]).round(0).to_string())


if __name__ == "__main__":
    main()
