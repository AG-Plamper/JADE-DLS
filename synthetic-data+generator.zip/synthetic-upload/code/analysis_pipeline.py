# -*- coding: utf-8 -*-
"""
analysis_pipeline.py
===========
Headless re-run of the JADE-DLS notebook workflow (B, C2/C4, D, NNLS, regularised fit) on a
synthetic Dataset (see simulate_data.py) or on any (processed_correlations, df_basedata) pair.

The analysis modules in the project root are imported, never modified; this file only chains
their functions in the order of JADE-DLS_workingvariant.ipynb, with the notebook defaults
collected in `Settings`, and without any per-case tuning. Figures that the modules create
unconditionally are discarded (Agg backend, plt.close).

Method tokens (analyze(..., methods=[...])):
    'B', 'C2', 'C4'          single apparent Rh (cumulant methods), n_found = 1 by definition
    'D', 'D:gap=3.0'         Method D, optional gap threshold override
    'NNLS'                   plain NNLS
    'Reg', 'Reg:alpha=0.05'  regularised fit; returns TWO results: 'Reg' (all files) and
                             'Reg-cur' (files with cleanly separated peaks only, see curate())
For D, NNLS and Reg (and, since 2026-11-02, B, C2 and C4: columns q^2, Gamma / best_b, best_c, ...) the per-file fit table is attached to the result ('table') so that curation
and the cross-file clustering can be re-run later without refitting (cluster_from_table()).

Each result: {'method','n_found','rh' (ascending, nm),'abundance','pdi','extra','error', ['table']}
"""
import contextlib
import io
import sys
import warnings
from dataclasses import dataclass
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from scipy.constants import k as K_B  # noqa: E402

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent       # repository root: code/ -> synthetic-upload/ -> repository root
for p in (str(ROOT), str(HERE)):
    if p not in sys.path:
        sys.path.insert(0, p)

from weighting import compute_weights_for_all, apply_weights_to_correlations  # noqa: E402
from cumulants import calculate_g2_B, plot_processed_correlations, analyze_diffusion_coefficient  # noqa: E402
from cumulants_C import get_adaptive_initial_parameters, plot_processed_correlations_iterative  # noqa: E402
from cumulants_D import (fit_correlations_method_D, fit_cumulant_D, cluster_gammas,  # noqa: E402
                         calculate_moments_from_gammas)
from clustering import cluster_all_gammas, get_reliable_gamma_cols  # noqa: E402
from regularized import nnls_all, nnls_reg_all, calculate_decay_rates  # noqa: E402
import fast_regularized_fit  # noqa: E402

ALL_METHODS = ("B", "C2", "C4", "D", "NNLS", "Reg")


# --------------------------------------------------------------------------- settings
@dataclass
class Settings:
    """Notebook defaults (JADE-DLS_workingvariant.ipynb); clustering as agreed: d=2.0, f_min=0.3."""
    weighting: bool = True
    fast_reg: bool = True            # analytic gradient + headless plots for nnls_reg (see fast_regularized_fit.py)
    # B
    b_fit_limits: tuple = (0, 0.0002)
    b_q2_range: tuple = (0, 0.001)
    b_through_origin: bool = False     # Gamma-q^2 regression of method B with free intercept (as C2/C4)
    # C
    c_fit_limits: tuple = (1e-9, 10)
    c_method: str = "lm"
    c_base: tuple = (0.8, 10000, 0, 0, 0, 0)
    # D
    d_n_max: int = 25
    d_n_start: int = 1
    d_gap_threshold: float = 2.0
    # NNLS
    nnls_points: int = 100
    nnls_prominence: float = 0.01
    nnls_distance: int = 1
    # regularised fit
    reg_points: int = 200
    reg_prominence: float = 0.005
    reg_distance: int = 1
    reg_alpha: float = 0.2
    reg_fit_beta: bool = True
    reg_normalize: bool = True
    reg_peak_method: str = "centroid"
    reg_sparsity: float = 0
    # clustering (all multimodal methods)
    cluster_distance: float = 2.0
    cluster_min_abundance: float = 0.3
    cluster_strategy: str = "silhouette_refined"
    # curation of regularised fits ("peaks cleanly separated")
    valley_max: float = 0.05         # valley between neighbouring peaks <= 5 % of the smaller peak
    min_files: int = 6               # fewer retained files -> unresolved
    dedupe_tol: float = 0.01         # peaks with the same centroid (rel. diff < 1 %) are one peak

    def as_dict(self):
        return dict(self.__dict__)


# --------------------------------------------------------------------------- C fit functions
# verbatim from the notebook (they live in the notebook, not in cumulants_C.py)
def fit_function2(x, a, b, c, f):
    inner_term = 1 + 0.5 * c * x ** 2
    return f + a * (np.exp(-b * x) * inner_term) ** 2


def fit_function4(x, a, b, c, d, e, f):
    inner_term = 1 + 0.5 * c * x ** 2 - (d * x ** 3) / 6 + (e * x ** 4) / 24
    return f + a * (np.exp(-b * x) * inner_term) ** 2


C_FUNCS = {"C2": fit_function2, "C4": fit_function4}


# --------------------------------------------------------------------------- helpers
@contextlib.contextmanager
def _quiet():
    with warnings.catch_warnings(), contextlib.redirect_stdout(io.StringIO()), \
            contextlib.redirect_stderr(io.StringIO()):
        warnings.simplefilter("ignore")
        try:
            yield
        finally:
            plt.close("all")


def _merge(df_basedata, fit_df):
    out = pd.merge(df_basedata, fit_df, on="filename", how="outer").reset_index(drop=True)
    out.index = out.index + 1
    return out


def c_constant(df_basedata):
    return (K_B * df_basedata["temperature [K]"].mean()
            / (6 * np.pi * df_basedata["viscosity [cp]"].mean() * 1e-3))


def _rh_from_slope(q2_coef, c):
    return c / (q2_coef * 1e-18) * 1e9


def _empty(method, error=None):
    return {"method": method, "n_found": None, "rh": [], "abundance": [], "pdi": None,
            "extra": {}, "error": error}


def parse_token(tok):
    """'D:gap=3.0' -> ('D', {'gap': 3.0})"""
    base, _, rest = tok.partition(":")
    params = {}
    if rest:
        for kv in rest.split(","):
            k, v = kv.split("=")
            params[k] = float(v)
    return base, params


_OVERRIDES = {"D": {"gap": "d_gap_threshold"},
              "Reg": {"alpha": "reg_alpha", "prom": "reg_prominence", "points": "reg_points"},
              "NNLS": {"prom": "nnls_prominence", "points": "nnls_points"}}


def _settings_for(s, base, params):
    kw = s.as_dict()
    for k, v in params.items():
        kw[_OVERRIDES[base][k]] = v
    return Settings(**kw)


_TABLE_PREFIXES = ("gamma_", "tau_", "valley_")
_TABLE_EXTRA = ("filename", "angle [°]", "q^2", "R_squared", "beta", "n_modes", "n_populations", "pdi",
                "dirac_gammas")


def _table_records(data):
    cols = [k for k in data.columns if k in _TABLE_EXTRA or k.startswith(_TABLE_PREFIXES)]
    return data[cols].to_dict("records")


def _cum_table(data):
    """Per-file table of a cumulant fit (all scalar columns: q^2, Gamma / best_b, best_c, ...), so that the Gamma-q^2 regression
    (intercept, other q^2 ranges, through the origin) can be redone later without refitting."""
    cols = [k for k in data.columns if pd.api.types.is_numeric_dtype(data[k]) or data[k].map(lambda v: isinstance(v, str)).all()]
    return data[cols].to_dict("records")


def _cluster(data, cols, s):
    return cluster_all_gammas(
        data, gamma_cols=cols, q_squared_col="q^2", enable_clustering=True, normalize_by_q2=True,
        n_clusters="auto", distance_threshold=s.cluster_distance, min_abundance=s.cluster_min_abundance,
        clustering_strategy=s.cluster_strategy, uncertainty_flags=False, uncertainty_threshold=0.5,
        plot=False)


def _gamma_cols(data, method):
    cols = [k for k in data.columns if k.startswith("gamma_")]
    if method == "D":
        cols = [k for k in cols if k != "gamma_mean"]
    return sorted(cols)


def _population_result(method, data, c, s, extra=None):
    """Cross-file clustering of the per-file gammas, then one Gamma-q^2 regression per population."""
    extra = dict(extra or {})
    cols = _gamma_cols(data, "D" if method.startswith("D") else method)
    clustered, info = _cluster(data, cols, s)
    reg = analyze_diffusion_coefficient(clustered, "q^2", get_reliable_gamma_cols(info), x_range=None,
                                        fit_through_origin=False)
    ab = list(info.get("population_abundances", []))
    pairs = []
    for i, row in reg.reset_index(drop=True).iterrows():
        slope = row["q^2_coef"]
        if np.isfinite(slope) and slope > 0:
            pairs.append((float(_rh_from_slope(slope, c)), float(ab[i]) if i < len(ab) else np.nan))
    pairs.sort()
    return {"method": method, "n_found": int(info["n_populations"]), "rh": [p[0] for p in pairs],
            "abundance": [p[1] for p in pairs], "pdi": extra.pop("pdi", None), "extra": extra,
            "error": None}


# --------------------------------------------------------------------------- curation
def curate(data, s):
    """Keep only files whose regularised distribution has cleanly separated peaks.

    Per file, neighbouring peaks with the same centroid (rel. diff < dedupe_tol) are one peak (the
    duplicate's gamma is blanked). Every remaining pair of neighbouring peaks must have a valley
    <= valley_max of the smaller peak height. Files with a single peak pass (nothing indicates a
    merge). Returns (curated table, number of files kept). Uses no ground truth."""
    tau_cols = sorted((k for k in data.columns if k.startswith("tau_")), key=lambda k: int(k.split("_")[1]))
    keep, blank = [], []
    for idx, row in data.iterrows():
        taus = [row[k] for k in tau_cols]
        pk = [i for i, t in enumerate(taus) if np.isfinite(t)]
        ok = True
        for a, b in zip(pk[:-1], pk[1:]):
            if abs(taus[b] / taus[a] - 1) < s.dedupe_tol:
                blank.append((idx, b))
                continue
            v = row.get(f"valley_{a + 1}", np.nan)
            if not (np.isfinite(v) and v <= s.valley_max):
                ok = False
        if ok:
            keep.append(idx)
    cur = data.loc[keep].copy()
    for idx, b in blank:
        if idx in cur.index:
            cur.loc[idx, f"gamma_{b + 1}"] = np.nan
    return cur.reset_index(drop=True), len(keep)


def cluster_from_table(method, table, c, s, curated=False):
    """Post-processing entry point: (curation) + clustering + regression from a stored fit table."""
    data = pd.DataFrame(table) if not isinstance(table, pd.DataFrame) else table.copy()
    n_all = len(data)
    if curated:
        data, n_keep = curate(data, s)
        extra = {"files_kept": n_keep, "files_total": n_all}
        if n_keep < s.min_files:
            return {"method": method + "-cur", "n_found": 0, "rh": [], "abundance": [], "pdi": None,
                    "extra": extra, "error": None}
        data.index = data.index + 1
        res = _population_result(method + "-cur", data, c, s, extra)
        return res
    return _population_result(method, data, c, s)


# --------------------------------------------------------------------------- methods
def run_B(pc, base, c, s):
    dfB = calculate_g2_B(pc)
    fit = plot_processed_correlations(dfB, s.b_fit_limits, None, None)
    data = _merge(base, fit)
    reg = analyze_diffusion_coefficient(data, "q^2", ["Gamma"], ["Method B"], x_range=s.b_q2_range,
                                        fit_through_origin=s.b_through_origin)
    return {"B": {"method": "B", "n_found": 1,
                  "rh": [float(_rh_from_slope(reg["q^2_coef"].iloc[0], c))],
                  "abundance": [1.0], "pdi": None, "extra": {}, "error": None, "table": _cum_table(data)}}


def run_C(label, pc, base, c, s):
    fn = C_FUNCS[label]
    init = get_adaptive_initial_parameters(pc, fn, list(s.c_base), verbose=False)
    fit = plot_processed_correlations_iterative(pc, fn, s.c_fit_limits, init, method=s.c_method,
                                                plot_number_start=1)
    data = _merge(base, fit)
    reg = analyze_diffusion_coefficient(data, "q^2", ["best_b"], [fn.__name__], x_range=None,
                                        fit_through_origin=False)
    pdi = float((data["best_c"] / data["best_b"] ** 2).mean())
    return {label: {"method": label, "n_found": 1,
                    "rh": [float(_rh_from_slope(reg["q^2_coef"].iloc[0], c))],
                    "abundance": [1.0], "pdi": pdi, "extra": {}, "error": None, "table": _cum_table(data)}}


def d_fit_files(pc, s):
    """Dirac-delta fits of every file (the expensive part of Method D), done once per dataset.
    Same call as cumulants_D.fit_correlations_method_D makes: fit_cumulant_D(x, y, n_max, n_start,
    weights from the 'weight' column if present)."""
    fits = {}
    for name, df in pc.items():
        try:
            w = df["weight"].values if "weight" in df.columns else None
            r = fit_cumulant_D(df["t [s]"].values, df["g(2)-1"].values, n_max=s.d_n_max,
                               n_start=s.d_n_start, weights=w)
            y = df["g(2)-1"].values
            ss_tot = np.sum((y - np.mean(y)) ** 2)
            fits[name] = {"r": r, "r2": 1 - r["residual_ss"] / ss_tot if ss_tot != 0 else 0}
        except Exception as e:
            fits[name] = {"error": str(e)}
    return fits


def d_table(fits, base, gap):
    """Per-file table for one gap threshold, same columns as fit_correlations_method_D."""
    rows = []
    for name, f in fits.items():
        row = {"filename": name}
        if "error" in f:
            row["Error"] = f["error"]
        else:
            r = f["r"]
            _, reps, info = cluster_gammas(r["gammas"], gap_threshold=gap)
            row.update({"n_modes": r["n_modes"], "beta": r["beta"], "residual_ss": r["residual_ss"],
                        "n_populations": info["n_clusters"]})
            for i, g in enumerate(reps):
                row[f"gamma_{i + 1}"] = g
            m = calculate_moments_from_gammas(r["gammas"])
            row.update({"gamma_mean": m["gamma_mean"], "moment_2": m["gamma_2"], "moment_3": m["gamma_3"],
                        "pdi": m["pdi"], "skewness": m["skewness"], "moment_4": m["gamma_4"],
                        "kurtosis": m["kurtosis"], "R-squared": f["r2"],
                        "dirac_gammas": [float(g) for g in r["gammas"]]})
        rows.append(row)
    return _merge(base, pd.DataFrame(rows))


def run_D_tokens(toks, pc, base, c, s0):
    """All D tokens of one analysis share a single set of Dirac fits; they differ only in the gap."""
    fits = d_fit_files(pc, s0)
    out = {}
    for tok in toks:
        _, params = parse_token(tok)
        gap = params.get("gap", s0.d_gap_threshold)
        data = d_table(fits, base, gap)
        extra = {"pdi": float(data["pdi"].mean()), "n_modes_mean": float(data["n_modes"].mean()),
                 "n_pop_per_file_mean": float(data["n_populations"].mean())}
        res = _population_result(tok, data, c, s0, extra)
        res["table"] = _table_records(data)
        out[tok] = res
    return out


def run_NNLS(tok, pc, base, c, s):
    par = {"decay_times": np.logspace(-8, 1, int(s.nnls_points)), "prominence": s.nnls_prominence,
           "distance": s.nnls_distance}
    data = _merge(base, nnls_all(pc, par))
    data = calculate_decay_rates(data, sorted(k for k in data.columns if k.startswith("tau_")))
    res = _population_result(tok, data, c, s)
    res["table"] = _table_records(data)
    return {tok: res}


def run_Reg(tok, pc, base, c, s):
    decay = np.logspace(-8, 1, int(s.reg_points))
    par = {"decay_times": decay, "prominence": s.reg_prominence, "distance": s.reg_distance,
           "alpha": s.reg_alpha, "fit_beta": s.reg_fit_beta, "normalize": s.reg_normalize,
           "peak_method": s.reg_peak_method, "sparsity_penalty": s.reg_sparsity}
    df, full = nnls_reg_all(pc, par)
    data = _merge(base, df)
    tau_cols = sorted(k for k in data.columns if k.startswith("tau_"))
    data = calculate_decay_rates(data, tau_cols)
    # valley depth between neighbouring peaks, from the stored distributions
    valleys = {}
    for name, fr in full.items():
        f, pk = fr["f_optimized"], list(fr["peaks"])
        v = []
        for a, b in zip(pk[:-1], pk[1:]):
            lo = min(f[a], f[b])
            v.append(float(f[a:b + 1].min() / lo) if lo > 0 else np.nan)
        valleys[name] = v
    for j in range(max(len(tau_cols) - 1, 0)):
        data[f"valley_{j + 1}"] = data["filename"].map(
            lambda n, j=j: valleys.get(n, [])[j] if len(valleys.get(n, [])) > j else np.nan)
    extra = {"beta_mean": float(data["beta"].mean()) if "beta" in data else None}
    res = _population_result(tok, data, c, s, dict(extra))
    res["table"] = _table_records(data)
    cur = cluster_from_table(tok, data, c, s, curated=True)
    return {tok: res, tok + "-cur": cur}


# --------------------------------------------------------------------------- driver
def prepare(processed, df_basedata, weighting):
    """Optional Biganzoli-Ferri weights, estimated from the (noisy) curves as in the notebook."""
    if not weighting:
        return processed
    wd = compute_weights_for_all(processed, df_basedata)
    return apply_weights_to_correlations(processed, wd)


def analyze(processed, df_basedata, settings=None, methods=ALL_METHODS):
    """Run the requested method tokens. Returns {result name: result}; 'Reg' tokens give two entries."""
    s0 = settings or Settings()
    c = c_constant(df_basedata)
    if s0.fast_reg:
        fast_regularized_fit.enable()
    else:
        fast_regularized_fit.disable()
    out = {}
    try:
        with _quiet():
            pc = prepare(processed, df_basedata, s0.weighting)
    except Exception as e:  # weights could not be estimated
        for m in methods:
            out[m] = _empty(m, f"weights: {type(e).__name__}: {e}")
        return out
    d_toks = [t for t in methods if parse_token(t)[0] == "D"]
    if d_toks:
        try:
            with _quiet():
                out.update(run_D_tokens(d_toks, pc, df_basedata, c, s0))
        except Exception as e:
            for t in d_toks:
                out[t] = _empty(t, f"{type(e).__name__}: {e}")
    for tok in methods:
        base_name, params = parse_token(tok)
        if base_name == "D":
            continue
        s = _settings_for(s0, base_name, params)
        try:
            with _quiet():
                if base_name == "B":
                    out.update(run_B(pc, df_basedata, c, s))
                elif base_name in C_FUNCS:
                    out.update(run_C(base_name, pc, df_basedata, c, s))
                elif base_name == "NNLS":
                    out.update(run_NNLS(tok, pc, df_basedata, c, s))
                elif base_name == "Reg":
                    out.update(run_Reg(tok, pc, df_basedata, c, s))
                else:
                    raise ValueError(f"unknown method {tok}")
        except Exception as e:
            out[tok] = _empty(tok, f"{type(e).__name__}: {e}")
            if base_name == "Reg":
                out[tok + "-cur"] = _empty(tok + "-cur", f"{type(e).__name__}: {e}")
    return out


def analyze_dataset(ds, settings=None, methods=ALL_METHODS):
    """Convenience wrapper for a simulate_data.Dataset."""
    s = settings or Settings()
    if ds.scenario.noise_level == 0:      # no noise -> weights are undefined; unweighted by construction
        s = Settings(**{**s.as_dict(), "weighting": False})
    return analyze(ds.processed_correlations(), ds.df_basedata, s, methods)


# --------------------------------------------------------------------------- evaluation
def evaluate(result, truth, tol=0.20):
    """Compare one method result with the ground truth.

    count_ok  : number of populations found == true number
    success   : count_ok and every population's Rh within +-tol of its true Rh (sorted matching)
    spurious  : more populations found than present
    rel_err   : per-population relative Rh error (found/true - 1), sorted matching, if count_ok
    rel_err_z : relative error of the single apparent Rh against the true z-average Rh (B, C)
    """
    rh, n_true = result["rh"], truth["n_pop"]
    n = result["n_found"]
    ev = {"count_ok": None, "success": None, "spurious": None, "rel_err": [], "rel_err_z": None}
    if n is None:
        return ev
    ev["count_ok"] = bool(n == n_true)
    ev["spurious"] = bool(n > n_true)
    if len(rh) == n_true:
        ev["rel_err"] = [float(r / t - 1) for r, t in zip(rh, truth["rh_pops"])]
    ev["success"] = bool(ev["count_ok"] and len(ev["rel_err"]) == n_true
                         and all(abs(e) <= tol for e in ev["rel_err"]))
    if result["method"] in ("B", "C2", "C4") and rh:
        # reference of the cumulant methods (free-intercept regression): the z-average (angle-independent fractions)
        # or, for angle-dependent fractions, the slope the same regression gives for the exact mean decay rates
        ref = truth.get("rh_z_reg_free", truth["rh_z"])
        ev["rel_err_z"] = float(rh[0] / ref - 1)
    return ev
