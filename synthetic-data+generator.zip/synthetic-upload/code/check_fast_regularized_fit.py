# -*- coding: utf-8 -*-
"""
check_fast_regularized_fit.py -- equivalence check of fast_regularized_fit.py (analytic gradient) against the optimiser of regularized.py
on 324 simulated curves (mono / bimodal, noise-free / correlated noise, weighted).

    python code/check_fast_regularized_fit.py [--jobs 14]

Writes results/checks/fast_regularized_fit.csv (peak counts, centroid, f(tau), beta and R^2 differences, run times of both variants per curve) and prints a
summary. The fast variant is used for the benchmark only if peak counts agree and the peak centroids (tau) agree to within tolerance. The run-time columns
depend on the machine; all other columns are deterministic.
"""
import argparse
import contextlib
import io
import os
import sys
import time
import warnings
from pathlib import Path

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "1")
os.environ["MPLBACKEND"] = "Agg"        # workers must never open figure windows
HERE = Path(__file__).resolve().parent
import paths as P  # noqa: E402  (locations of data, results, ...)
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(P.ROOT))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

SPECS = {
    "mono0.05": [(50, 0.05, 1.0)], "mono0.2": [(50, 0.20, 1.0)],
    "r2": [(50 / 2 ** .5, .1, .5), (50 * 2 ** .5, .1, .5)],
    "r3": [(50 / 3 ** .5, .05, .5), (50 * 3 ** .5, .05, .5)],
    "r5": [(50 / 5 ** .5, .1, .5), (50 * 5 ** .5, .1, .5)],
    "r10": [(50 / 10 ** .5, .2, .8), (50 * 10 ** .5, .2, .2)],
}
CONDS = [(0.0, "white"), (1.0, "correlated"), (2.0, "correlated")]
PER_COMBO = 18

PAR_REG = {"decay_times": np.logspace(-8, 1, 200), "prominence": 0.005, "distance": 1, "alpha": 0.2,
           "fit_beta": True, "normalize": True, "peak_method": "centroid", "sparsity_penalty": 0}
PAR_NNLS = {"decay_times": np.logspace(-8, 1, 100), "prominence": 0.01, "distance": 1}


def _q():
    return contextlib.redirect_stdout(io.StringIO())


def one_curve(spec, lvl, mode, seed, fname):
    import simulate_data
    import weighting as wt
    import regularized as rg
    import fast_regularized_fit
    warnings.simplefilter("ignore")
    ds = simulate_data.simulate(SPECS[spec], noise_level=lvl, noise_mode=mode, seed=seed, name=spec)
    pc = ds.processed_correlations()
    df = pc[fname].copy()
    if lvl > 0:
        df["weight"] = wt.estimate_weights(df["t [s]"].to_numpy(), df["g(2)-1"].to_numpy(),
                                           330, 330, 12, verbose=False)
    rec = {"spec": spec, "level": lvl, "mode": mode, "seed": seed, "file": fname}
    out = {}
    for tag in ("orig", "fast"):
        fast_regularized_fit.enable() if tag == "fast" else fast_regularized_fit.disable()
        t0 = time.perf_counter()
        with _q():
            r = rg.nnls_reg(df, "a", PAR_REG, 1)
        t1 = time.perf_counter()
        with _q():
            n = rg.nnls(df, "a", PAR_NNLS, 1)
        t2 = time.perf_counter()
        plt.close("all")
        out[tag] = (r, n)
        rec[f"reg_time_{tag}"], rec[f"nnls_time_{tag}"] = t1 - t0, t2 - t1
    fast_regularized_fit.disable()
    (r0, f0, *_), (r1, f1, *_) = out["orig"][0], out["fast"][0]
    taus0 = sorted(v for k, v in r0.items() if k.startswith("tau_"))
    taus1 = sorted(v for k, v in r1.items() if k.startswith("tau_"))
    rec["reg_npeaks_orig"], rec["reg_npeaks_fast"] = len(taus0), len(taus1)
    rec["reg_tau_maxrel"] = (np.max(np.abs(np.array(taus1) / np.array(taus0) - 1))
                             if len(taus0) == len(taus1) and taus0 else np.nan)
    rec["reg_f_maxdiff"] = float(np.max(np.abs(f1 - f0)) / max(np.max(f0), 1e-30))
    rec["reg_beta_diff"] = abs(r1["beta"] - r0["beta"])
    rec["reg_R2_diff"] = abs(r1["R_squared"] - r0["R_squared"])
    n0, n1 = out["orig"][1], out["fast"][1]
    nt0 = sorted(v for k, v in n0.items() if k.startswith("tau_"))
    nt1 = sorted(v for k, v in n1.items() if k.startswith("tau_"))
    rec["nnls_npeaks_orig"], rec["nnls_npeaks_fast"] = len(nt0), len(nt1)
    rec["nnls_tau_maxrel"] = (np.max(np.abs(np.array(nt1) / np.array(nt0) - 1))
                              if len(nt0) == len(nt1) and nt0 else np.nan)
    rec["nnls_R2_diff"] = abs(n1["R_squared"] - n0["R_squared"])
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=14)
    a = ap.parse_args()
    import simulate_data
    rng = np.random.default_rng(2026)
    tasks = []
    for spec in SPECS:
        for lvl, mode in CONDS:
            seed = int(rng.integers(1, 10_000))
            names = list(simulate_data.simulate(SPECS[spec], noise_level=lvl, noise_mode=mode, seed=seed,
                                        name=spec, angles=simulate_data.ANGLES_DEG).all_correlations)
            for fname in rng.choice(names, PER_COMBO, replace=False):
                tasks.append((spec, lvl, mode, seed, str(fname)))
    print(f"{len(tasks)} curves", flush=True)
    from joblib import Parallel, delayed
    rows = Parallel(n_jobs=a.jobs, batch_size=1, verbose=2)(delayed(one_curve)(*t) for t in tasks)
    df = pd.DataFrame(rows)
    df.to_csv(P.table("checks", "fast_regularized_fit.csv"), index=False)
    pd.set_option("display.width", 200)
    for m in ("reg", "nnls"):
        same = (df[f"{m}_npeaks_orig"] == df[f"{m}_npeaks_fast"])
        print(f"\n=== {m}: same number of peaks in {same.mean():.1%} of {len(df)} curves")
        ok = df[same]
        print(f"  centroid tau max rel diff: median {ok[f'{m}_tau_maxrel'].median():.2e}, "
              f"95% {ok[f'{m}_tau_maxrel'].quantile(.95):.2e}, max {ok[f'{m}_tau_maxrel'].max():.2e}")
        print(f"  R2 diff: max {df[f'{m}_R2_diff'].max():.2e}")
        print(f"  time orig {df[f'{m}_time_orig'].sum() / 60:.1f} min -> fast {df[f'{m}_time_fast'].sum() / 60:.1f} min"
              f"  (speed-up x{df[f'{m}_time_orig'].sum() / df[f'{m}_time_fast'].sum():.1f})")
    print(f"  reg f(tau) max diff / max f: median {df.reg_f_maxdiff.median():.2e}, max {df.reg_f_maxdiff.max():.2e}")
    bad = df[(df.reg_npeaks_orig != df.reg_npeaks_fast) | (df.nnls_npeaks_orig != df.nnls_npeaks_fast)]
    print("\ncurves with different peak counts:\n", bad[["spec", "level", "mode", "file", "reg_npeaks_orig",
          "reg_npeaks_fast", "nnls_npeaks_orig", "nnls_npeaks_fast"]].to_string(index=False))


if __name__ == "__main__":
    main()
