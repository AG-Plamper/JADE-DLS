# -*- coding: utf-8 -*-
"""
fast_regularized_fit.py
==========
Opt-in speed-up of regularized.nnls_reg() (and headless plotting for nnls()) for the benchmark.

regularized.py is NOT modified. Two runtime changes inside the `regularized` module namespace:

1. nnls_reg() calls scipy's `minimize` (SLSQP, normalised regularised fit) without a gradient, so
   scipy estimates it by finite differences (one objective evaluation per parameter and
   iteration). enable() swaps that name for a wrapper that supplies the exact analytic gradient
   of the very same objective, recovered from the closure of the function that regularized.py
   passes in. Any call that is not recognised is forwarded unchanged to scipy. The objective is
   not convex, so iterates can differ slightly from the finite-difference run;
   (results/checks/fast_regularized_fit.csv quantifies that on simulated curves.)
2. nnls() and nnls_reg() build a four-panel matplotlib figure on every call (about half of the
   remaining run time). enable() replaces `regularized.plt` by a stub for the figure calls only.
   Plotting has no influence on the results.

Plain NNLS keeps scipy's own finite-difference least_squares: the problem is degenerate, an
exact Jacobian gives no speed-up and may end at a different but equally valid solution.

    import fast_regularized_fit
    fast_regularized_fit.enable()      # or:  with fast_regularized_fit.fast(): ...
"""
import contextlib
import inspect

import numpy as np
import regularized as _rg

_ORIG = {"minimize": _rg.minimize, "plt": _rg.plt}
_FALLBACKS = {"n": 0, "fast": 0}
_NEG = -1e-8     # forward-difference step of scipy is ~1.5e-8: values above this still see slope 1


def _reg_jac(fun):
    """Analytic gradient of nnls_reg's objective_function (normalised branch), or None."""
    if not getattr(fun, "__qualname__", "").endswith("nnls_reg.<locals>.objective_function"):
        return None
    nl = inspect.getclosurevars(fun).nonlocals
    try:
        T, D, D2, alpha, fit_beta = nl["T"], nl["D"], nl["D2"], nl["alpha"], nl["fit_beta"]
        rr = inspect.getclosurevars(nl["residuals_regularized"]).nonlocals
        sqrt_w, sparsity = rr["sqrt_w"], rr["sparsity_penalty"]
        if not rr["normalize"]:
            return None
    except KeyError:
        return None

    def jac(p):
        p = np.asarray(p, dtype=float)
        if fit_beta:
            b = max(p[0], 0.0)
            raw = p[1:]
        else:
            b = 1.0
            raw = p
        c = np.maximum(raw, 0.0)
        s = c.sum()
        fn = c / s if s > 0 else c
        Tf = T @ fn
        r1 = sqrt_w * (b * Tf ** 2 - D)
        r2 = alpha * (D2 @ fn)
        gf = 2.0 * (T.T @ (r1 * sqrt_w * 2.0 * b * Tf)) + 2.0 * alpha * (D2.T @ r2)
        if sparsity > 0:
            gf = gf + 2.0 * sparsity ** 2 * fn
        gc = (gf - gf @ fn) / s if s > 0 else gf
        gc = gc * (raw > _NEG)
        if fit_beta:
            gb = 2.0 * np.sum(r1 * sqrt_w * Tf ** 2) * (p[0] > _NEG)
            return np.concatenate([[gb], gc])
        return gc

    return jac


def _minimize_fast(fun, x0, *args, **kwargs):
    jac = _reg_jac(fun) if kwargs.get("method") == "SLSQP" and "jac" not in kwargs else None
    if jac is None:
        _FALLBACKS["n"] += 1
        return _ORIG["minimize"](fun, x0, *args, **kwargs)
    _FALLBACKS["fast"] += 1
    cons = kwargs.get("constraints")
    if isinstance(cons, dict) and cons.get("type") == "eq" and "jac" not in cons:
        n = len(x0)
        n_beta = 1 if len(x0) > 1 and kwargs["bounds"][0] == (0.0, 2.0) else 0
        g = np.concatenate([np.zeros(n_beta), np.ones(n - n_beta)])
        kwargs["constraints"] = {**cons, "jac": lambda p, g=g: g}
    return _ORIG["minimize"](fun, x0, *args, jac=jac, **kwargs)


class _StubAxes:
    """Absorbs every axes/figure call of the plotting code."""
    def __getattr__(self, name):
        return lambda *a, **k: _StubAxes()

    def __iter__(self):
        return iter([_StubAxes()] * 4)


class _StubPlt:
    """Stand-in for matplotlib.pyplot inside `regularized`: figure calls are no-ops, anything else
    is forwarded to the real pyplot."""
    def subplots(self, *a, **k):
        return _StubAxes(), [_StubAxes() for _ in range(4)]

    def tight_layout(self, *a, **k):
        pass

    def show(self, *a, **k):
        pass

    def __getattr__(self, name):
        import matplotlib.pyplot as plt
        return getattr(plt, name)


def enable(headless_plots=True):
    _rg.minimize = _minimize_fast
    if headless_plots:
        _rg.plt = _StubPlt()


def disable():
    _rg.minimize = _ORIG["minimize"]
    _rg.plt = _ORIG["plt"]


@contextlib.contextmanager
def fast():
    enable()
    try:
        yield
    finally:
        disable()


def is_enabled():
    return _rg.minimize is _minimize_fast


def stats():
    """Number of optimiser calls that used the analytic derivative / fell back to scipy's default."""
    return dict(_FALLBACKS)
