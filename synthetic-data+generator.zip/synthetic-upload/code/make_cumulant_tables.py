# -*- coding: utf-8 -*-
"""
make_cumulant_tables.py -- results of the cumulant methods B, C2 and C4 for the monomodal, bimodal and trimodal samples.

    python code/make_cumulant_tables.py

Sources (stored per-file tables, nothing is refitted; written by run_study.py):
  data/raw/cumtab   monomodal (50 nm) and the bimodal samples, groups 'cum' (C2, C4) and 'B'; s = 0 (1 data set), 1, 2 (10 replicates)
  data/raw/tri      the trimodal samples, same groups and replicates
The reference of the cumulant methods is the true z-average (intensity-weighted mean Rh) of the sample and the true PDI of the mixture
(sum_i f_i Gamma_i^2 / (sum_i f_i Gamma_i)^2 - 1). Writes, pooled over the population PDI (s = 1 and 2):
  results/1_monomodal/cumulants.csv   noise level x population PDI
  results/2_bimodal/cumulants.csv     noise level x size ratio x intensity split
  results/3_trimodal/cumulants.csv    noise level x neighbour ratio x intensity split
Columns per method: n runs, median |Rh / z-average - 1|, fraction of runs within +-20 % of the z-average, median fitted PDI / true PDI of the mixture (C2, C4),
median Gamma-q^2 intercept (a straight line Gamma = Gamma0 + D q^2 is fitted to the per-file Gamma values; Gamma0 relative to the fitted Gamma at the mean q^2,
truth 0 for diffusive decay).
"""
import json
import re

import numpy as np
import pandas as pd

import paths as P

METHODS = ("B", "C2", "C4")
GAMMA_COL = {"B": "Gamma", "C2": "best_b", "C4": "best_b"}
TOL = 0.20
TOPIC = {"mono": "1_monomodal", "bi": "2_bimodal", "tri": "3_trimodal"}


def parse(g):
    if g.startswith("mono"):
        return "mono", np.nan, float(re.search(r"pdi([\d.]+)", g)[1]), ""
    m = re.match(r"(bi|tri)_r([\d.]+)_pdi([\d.]+)(_i\d+)?", g)
    return m[1], float(m[2]), float(m[3]), m[4] or ""


def intercept_ratio(table, method):
    t = pd.DataFrame(table)
    q2, gam = t["q^2"].to_numpy(float), t[GAMMA_COL[method]].to_numpy(float)
    ok = np.isfinite(q2) & np.isfinite(gam)
    if ok.sum() < 3:
        return np.nan
    slope, icpt = np.polyfit(q2[ok], gam[ok], 1)
    ref = icpt + slope * q2[ok].mean()
    return icpt / ref if ref else np.nan


def build_runs():
    """one row per run and cumulant method"""
    rows = []
    for folder in ("cumtab", "tri"):
        for p in sorted((P.RAW / folder).glob("*.json")):
            m = re.match(r"(.+)__(s\d)_\w+_r(\d+)_(cum|B)_w\.json$", p.name)
            if not m:
                continue
            geom, lv, rep = m[1], int(m[2][1]), int(m[3])
            r = json.loads(p.read_text(encoding="utf-8"))
            kind, ratio, pdi, suf = parse(geom)
            t = r["truth"]
            for meth, res in r["results"].items():
                if meth not in METHODS or res.get("error") or not res.get("rh"):
                    continue
                rows.append(dict(geometry=geom, kind=kind, ratio=ratio, pdi_pop=pdi, split=suf, level=lv, rep=rep, method=meth,
                                 rh=res["rh"][0], pdi=res.get("pdi"), rh_z=t["rh_z"], pdi_mix=t["pdi_mix"],
                                 rh_true=";".join(f"{x:.4f}" for x in t["rh_pops"]),
                                 intercept=intercept_ratio(res["table"], meth) if res.get("table") else np.nan))
    d = pd.DataFrame(rows)
    d["rel_err"] = d.rh / d.rh_z - 1
    d["split"] = d["split"].fillna("")
    return d


def pooled_tables(d):
    for kind in ("mono", "bi", "tri"):
        x = d[(d.kind == kind) & (d.level > 0)]
        keys = ["level", "pdi_pop"] if kind == "mono" else ["level", "ratio", "split"]
        rows = []
        for k, g in x.groupby(keys):
            for m in METHODS:
                s = g[g.method == m]
                if s.empty:
                    continue
                row = dict(zip(keys, k))
                row.update(method=m, n=len(s), median_abs_err_vs_z=round(float(np.median(np.abs(s.rel_err))), 4),
                           frac_within20=round(float(np.mean(np.abs(s.rel_err) <= TOL)), 2),
                           pdi_ratio_median=round(float(np.nanmedian(s.pdi / s.pdi_mix)), 2) if s.pdi.notna().any() else np.nan,
                           intercept_median=round(float(np.nanmedian(s.intercept)), 3))
                rows.append(row)
        pd.DataFrame(rows).to_csv(P.table(TOPIC[kind], "cumulants.csv"), index=False)


def main():
    d = build_runs()
    pooled_tables(d)
    print("runs:", len(d))


if __name__ == "__main__":
    main()
