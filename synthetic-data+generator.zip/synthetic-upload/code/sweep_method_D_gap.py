# -*- coding: utf-8 -*-
"""
sweep_method_D_gap.py -- Method D at many gap thresholds from the stored Dirac fits (no refit).

    python code/sweep_method_D_gap.py [--jobs 14] [--sets main sizes] [--out method_D_gap.csv]

The stored per-file tables of Method D keep the Dirac-delta decay rates of every file. This script groups
them with another gap threshold (cumulants_D.cluster_gammas, linear ratio, split if ratio > gap), repeats the
cross-file clustering and regression of the pipeline and evaluates against the ground truth.
Reads data/raw/{main,sizes}/*_D_w.json (token "D" tables), writes results/4_parameter_sensitivity/method_D_gap.csv (counts, success and the recovered Rh values per run and gap).
"""
import argparse
import json
import os
import sys
import warnings
from pathlib import Path

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "1")
os.environ["MPLBACKEND"] = "Agg"
HERE = Path(__file__).resolve().parent
import paths as P  # noqa: E402  (locations of data, results, ...)
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(P.ROOT))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

GAPS = (1.5, 2.0, 2.25, 2.5, 2.75, 3.0, 3.5, 4.0, 5.0)


def one(path):
    warnings.simplefilter("ignore")
    import contextlib
    import io
    import analysis_pipeline as pl
    import simulate_data
    from cumulants_D import cluster_gammas
    r = json.loads(Path(path).read_text(encoding="utf-8"))
    tab = r["results"]["D"].get("table")
    if not tab:
        return []
    ds = simulate_data.simulate([(50.0, 0.05, 1.0)], noise_level=0, seed=0)
    c = pl.c_constant(ds.df_basedata)
    s = pl.Settings()
    out = []
    for gap in GAPS:
        rows = []
        for row in tab:
            g = row.get("dirac_gammas")
            if not g:
                continue
            row = {k: v for k, v in row.items() if not k.startswith("gamma_")}
            _, reps, _ = cluster_gammas(g, gap_threshold=gap)
            for i, x in enumerate(reps):
                row[f"gamma_{i + 1}"] = float(x)
            rows.append(row)
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                res = pl._population_result("D", pd.DataFrame(rows), c, s)
            ev = pl.evaluate(res, r["truth"])
            rec = {"geometry": r["geometry"], "noise_level": r["noise_level"], "rep": r["rep"], "gap": gap,
                   "n_found": res["n_found"], "count_ok": bool(ev["count_ok"]), "success": bool(ev["success"]),
                   "spurious": bool(ev["spurious"])}
            for i in range(4):                       # recovered Rh values (nm), ascending
                rec[f"rh_{i + 1}"] = res["rh"][i] if i < len(res["rh"]) else np.nan
            out.append(rec)
        except Exception as e:  # keep going; failures show up as missing rows
            out.append({"geometry": r["geometry"], "noise_level": r["noise_level"], "rep": r["rep"], "gap": gap,
                        "n_found": np.nan, "count_ok": False, "success": False, "spurious": False,
                        "error": f"{type(e).__name__}: {e}"})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=14)
    ap.add_argument("--sets", nargs="*", default=["main", "sizes"], help="raw result folders to read")
    ap.add_argument("--out", default="method_D_gap.csv", help="file name in results/4_parameter_sensitivity (use method_D_gap_split20-80.csv with --sets i20)")
    a = ap.parse_args()
    files = sorted(p for d in a.sets for p in (P.RAW / d).glob("*_D_w.json"))   # incl. noise-free
    print(len(files), "D task files", flush=True)
    from joblib import Parallel, delayed
    res = Parallel(n_jobs=a.jobs, batch_size=4, verbose=5)(delayed(one)(f) for f in files)
    df = pd.DataFrame([x for r in res for x in r])
    df.to_csv(P.table("4_parameter_sensitivity", a.out), index=False)
    print("wrote", P.table("4_parameter_sensitivity", a.out).relative_to(P.SYN).as_posix(), len(df), "rows; errors:", int(df.get("error", pd.Series(dtype=object)).notna().sum()))


if __name__ == "__main__":
    main()
