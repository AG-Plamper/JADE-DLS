# -*- coding: utf-8 -*-
"""
paths.py -- locations of the synthetic-data study (one place; the scripts in code/ import it as `import paths as P`).

<this folder>/
  code/        scripts, tests/
  data/input/  simulator input (ALV lag grid)
  data/raw/    per-file fit results (JSON), written by run_study.py            [not in the repository: recreate with run_study.py]
  data/records/ evaluated runs (CSV), written by run_study.py collect          [not in the repository]
  results/     summary tables, one folder per topic (see TOPICS)
  figures/     overview PDFs, numbered like the result folders

The repository root (parent folder of this folder) holds the JADE-DLS analysis modules (cumulants.py, cumulants_C.py, cumulants_D.py,
regularized.py, clustering.py, weighting.py, preprocessing.py) and the gold reference data. The study was run with JADE-DLS v3.0.
"""
from pathlib import Path

CODE = Path(__file__).resolve().parent
SYN = CODE.parent
ROOT = SYN.parent                      # repository root: analysis modules (cumulants.py, ...) and the gold reference data

DATA = SYN / "data"
RAW = DATA / "raw"
RECORDS = DATA / "records"
RESULTS = SYN / "results"

TOPICS = ("0_run_summaries", "1_monomodal", "2_bimodal", "3_trimodal", "4_parameter_sensitivity", "5_clustering_sensitivity",
          "6_noise_model_check", "checks")


def records(name):
    """data/records/records_<name>.csv (evaluated runs of one data set, written by `run_study.py collect`)."""
    return RECORDS / f"records_{name}.csv"


def table(topic, filename):
    """results/<topic>/<filename>; the topic folder is created when needed."""
    assert topic in TOPICS, topic
    folder = RESULTS / topic
    folder.mkdir(parents=True, exist_ok=True)
    return folder / filename
