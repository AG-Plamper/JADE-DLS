# -*- coding: utf-8 -*-
"""
run_study.py -- single entry point of the synthetic-data study.

    python code/run_study.py main    --jobs 14        # full study (resumable)
    python code/run_study.py main    --jobs 14 --geoms bi_r5_pdi0.1 --stages 0 1   # subset
    python code/run_study.py collect                  # raw JSON -> data/records/records_<set>.csv, results/0_run_summaries/<set>.csv

Design
------
Conditions : noise-free (1 dataset per geometry, unweighted) and correlated noise at s = 1 and 2
             (weighted fits, as in the notebook). Everything else is fixed to the notebook defaults
             (clustering d = 2.0, f_min = 0.3, see analysis_pipeline.Settings).
Groups     : cum    C2, C4                       on the reduced geometry set (all PDIs, 50/50) + monomodal sizes
             B      B (free-intercept regression)  same samples; the first runs of B regressed through the origin
                    (stored as 'B-origin' by evaluate_runs.collect)
             D      D, and gap thresholds 1.5, 3, 4   all geometries
             NNLS   NNLS                          all geometries
             Reg    regularised fit alpha = 0.2 (all files 'Reg' and curated 'Reg-cur'), all geometries
             RegAlpha regularised fit alpha = 0.05 and 0.1 (with curated variants), PDI 0.05 / 0.10 / 0.2 (both intensity
                    ratios) and the monomodal samples of 50 nm  (opt-in: --groups RegAlpha --name regalpha)
Stages     : 0  noise-free;  1  round 1 (10 replicates; cum: 20);  2  extension to 30 replicates for
             cells whose correct-count rate is still undecided (0.1 < rate < 0.9).
Stop rule  : a group is skipped at s = 2 for a geometry if at s = 1 the best correct-count rate of its
             variants fell below 10 %. Skipped cells are listed in data/records/skipped_<name>.csv. --no-stop-rule runs
             those cells too (resumable; used to fill them in afterwards).
Every (scenario, replicate, group) is one task, written to data/raw/<name>/<task>.json; existing
files are skipped, so interrupted runs resume and more replicates can be added later (seeds depend
on geometry and replicate index only).
"""
import argparse
import json
import os
import time
from pathlib import Path

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "1")
os.environ["MPLBACKEND"] = "Agg"        # workers must never open figure windows

import sys  # noqa: E402
HERE = Path(__file__).resolve().parent
import paths as P  # noqa: E402  (locations of data, results, ...)
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(P.ROOT))

import simulate_data  # noqa: E402
import analysis_pipeline as pl  # noqa: E402

RESULTS = P.RESULTS
GROUPS = {"cum": ("C2", "C4"),
          "B": ("B",),          # method B, free-intercept regression (replaces B of the first runs, which used the origin)
          "D": ("D", "D:gap=1.5", "D:gap=3", "D:gap=4"),
          "NNLS": ("NNLS",),
          "NNLSvar": ("NNLS:points=50", "NNLS:points=200", "NNLS:prom=0.1"),   # grid-point and prominence variants (opt-in)
          "NNLSvar2": ("NNLS:prom=0.2", "NNLS:points=400", "NNLS:points=400,prom=0.1"),   # second round (opt-in)
          "NNLSprom": ("NNLS:prom=0.2",),   # prominence 0.2 alone, 100 points (opt-in; cost of the default)
          "NNLSp05": ("NNLS:prom=0.05",),   # prominence 0.05 alone, 100 points (opt-in)
          "Reg": ("Reg",),
          "RegVar": ("Reg:prom=0.02", "Reg:prom=0.05", "Reg:points=100"),   # grid and prominence variants (opt-in)
          "Reg400": ("Reg:points=400",),   # 400 grid points, small subsets only (a task takes minutes)
          "RegAlpha": ("Reg:alpha=0.05", "Reg:alpha=0.1"),
          "RegAlpha4": ("Reg:alpha=0.4",)}   # alpha 0.4 on the RegAlpha samples (opt-in; --name regalpha)
LEVELS = (1.0, 2.0)
MODE = "correlated"
ROUND1_REPS, ROUND2_REPS, CUM_REPS = 10, 30, 20
STOP_THRESHOLD = 0.10
CUM_LIKE = ("cum", "B")      # groups of the cumulant methods: CUM_REPS replicates, no stop rule
UNCERTAIN = (0.10, 0.90)


def group_geometries(group, all_geoms):
    if group in CUM_LIKE:
        return ([g for g in simulate_data.cumulant_geometries() if g in all_geoms]
                + [g for g in all_geoms if g in simulate_data.size_geometries() or g in simulate_data.ff_geometries() or g.endswith(("_i80", "_i20")) or g.startswith("tri_")])
    if group in ("RegAlpha", "RegAlpha4"):
        return [g for g in all_geoms if g.startswith("mono_pdi") or "pdi0.05" in g or "pdi0.1" in g or "pdi0.2" in g]
    return list(all_geoms)


def task_id(scn, rep, group, weighted):
    return f"{scn.key}_r{rep:03d}_{group}_{'w' if weighted else 'u'}"


def run_task(scn, rep, group, weighted, outdir, settings_kw=None):
    """Simulate one dataset and run one method group on it; write JSON. Returns the path."""
    out = Path(outdir) / f"{task_id(scn, rep, group, weighted)}.json"
    if out.exists():
        return out
    t0 = time.perf_counter()
    ds = simulate_data.simulate_dataset(scn, rep)
    s = pl.Settings(**{**(settings_kw or {}), "weighting": weighted})
    res = pl.analyze_dataset(ds, s, GROUPS[group])
    rec = {
        "key": scn.key, "geometry": scn.geometry, "noise_level": scn.noise_level,
        "noise_mode": scn.noise_mode if scn.noise_level > 0 else "white", "rep": rep,
        "weighted": bool(weighted and scn.noise_level > 0), "group": group,
        "seconds": time.perf_counter() - t0, "truth": ds.truth, "results": res,
        "eval": {m: pl.evaluate(r, ds.truth) for m, r in res.items()},
        "settings": s.as_dict(),
    }
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_suffix(".tmp")
    tmp.write_text(json.dumps(rec, default=float), encoding="utf-8")
    tmp.replace(out)
    return out


def execute(tasks, jobs):
    todo = [t for t in tasks if not (Path(t[4]) / f"{task_id(*t[:4])}.json").exists()]
    print(f"  {len(tasks)} tasks, {len(tasks) - len(todo)} already done, {len(todo)} to run", flush=True)
    if not todo:
        return
    from joblib import Parallel, delayed
    t0 = time.time()
    Parallel(n_jobs=jobs, batch_size=1, verbose=5)(delayed(run_task)(*t) for t in todo)
    print(f"  done in {(time.time() - t0) / 60:.1f} min", flush=True)


# --------------------------------------------------------------------------- cell state
def cell_rates(out, scn_key, group):
    """{token: (n_runs, n_count_ok)} over the existing replicates of one (scenario, group) cell."""
    stats = {}
    for f in Path(out).glob(f"{scn_key}_r*_{group}_*.json"):
        r = json.loads(f.read_text(encoding="utf-8"))
        for m, ev in r["eval"].items():
            n, k = stats.get(m, (0, 0))
            stats[m] = (n + 1, k + bool(ev["count_ok"]))
    return stats


def best_rate(stats):
    return max((k / n for n, k in stats.values() if n), default=float("nan"))


def is_uncertain(stats):
    return any(n and UNCERTAIN[0] < k / n < UNCERTAIN[1] for n, k in stats.values())


def scenario(geom, level):
    return simulate_data.make_scenarios([geom], (level,), (MODE,))[0]


def run_main(a):
    out = P.RAW / a.name
    all_geoms = a.geoms or list(simulate_data.geometries())
    groups = [g for g in GROUPS if g in a.groups]
    cells = {g: group_geometries(g, all_geoms) for g in groups}
    skipped = []
    print(f"geometries: {len(all_geoms)}; cells per group: { {g: len(v) for g, v in cells.items()} }", flush=True)

    if 0 in a.stages:
        print("=== stage 0: noise-free", flush=True)
        execute([(scenario(geo, 0.0), 0, g, True, out) for g in groups for geo in cells[g]], a.jobs)

    def alive(geo, g, lvl):
        i = LEVELS.index(lvl)
        if i == 0 or g in CUM_LIKE or a.no_stop_rule:
            return True
        prev = cell_rates(out, scenario(geo, LEVELS[i - 1]).key, g)
        rate = best_rate(prev)
        ok = not (rate == rate and rate < STOP_THRESHOLD)
        if not ok:
            skipped.append({"geometry": geo, "group": g, "noise_level": lvl,
                            "reason": f"best correct-count rate {rate:.2f} < {STOP_THRESHOLD} at s={LEVELS[i - 1]:g}"})
        return ok

    if 1 in a.stages:
        print(f"=== stage 1: round 1 ({ROUND1_REPS} replicates; cum {CUM_REPS})", flush=True)
        for lvl in LEVELS:
            tasks = []
            for g in groups:
                n = CUM_REPS if g in CUM_LIKE else ROUND1_REPS
                for geo in cells[g]:
                    if alive(geo, g, lvl):
                        tasks += [(scenario(geo, lvl), r, g, True, out) for r in range(n)]
            print(f"--- s = {lvl:g}", flush=True)
            execute(tasks, a.jobs)

    if 2 in a.stages:
        print(f"=== stage 2: extension to {ROUND2_REPS} replicates where the rate is undecided", flush=True)
        for lvl in LEVELS:
            tasks = []
            for g in groups:
                if g in CUM_LIKE:
                    continue
                for geo in cells[g]:
                    scn = scenario(geo, lvl)
                    st = cell_rates(out, scn.key, g)
                    if st and is_uncertain(st):
                        tasks += [(scn, r, g, True, out) for r in range(ROUND1_REPS, ROUND2_REPS)]
            print(f"--- s = {lvl:g}", flush=True)
            execute(tasks, a.jobs)

    import pandas as pd
    P.RECORDS.mkdir(parents=True, exist_ok=True)
    if skipped:
        pd.DataFrame(skipped).drop_duplicates().to_csv(P.RECORDS / f"skipped_{a.name}.csv", index=False)
    cmd_collect([a.name])


def cmd_collect(setnames):
    import evaluate_runs
    P.RECORDS.mkdir(parents=True, exist_ok=True)
    for name in setnames:
        d = P.RAW / name
        if not d.exists():
            continue
        df = evaluate_runs.collect(d)
        df.to_csv(P.records(name), index=False)
        evaluate_runs.summarize(df).to_csv(P.table("0_run_summaries", f"{name}.csv"), index=False)
        print(f"{name}: {len(df)} records -> data/records/records_{name}.csv, results/0_run_summaries/{name}.csv")


def keep_system_awake():
    """Windows: ask the OS not to go to idle sleep while this process runs (SetThreadExecutionState,
    ES_CONTINUOUS | ES_SYSTEM_REQUIRED). The display may still switch off; the request vanishes with
    the process, and no user setting is changed. A closed lid, manual sleep or shutdown still stop it."""
    if os.name != "nt":
        return False
    import ctypes
    return bool(ctypes.windll.kernel32.SetThreadExecutionState(0x80000001))


def main():
    global ROUND1_REPS, ROUND2_REPS, CUM_REPS, LEVELS
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cmd", choices=["main", "collect"])
    ap.add_argument("--jobs", type=int, default=max(1, (os.cpu_count() or 2) // 2 - 2))
    ap.add_argument("--geoms", nargs="*", default=None, help="geometry ids (default: all 45)")
    ap.add_argument("--groups", nargs="*", default=[g for g in GROUPS if g not in ("RegAlpha", "NNLSvar", "NNLSvar2", "NNLSprom", "RegVar", "Reg400", "NNLSp05", "RegAlpha4")],
                    choices=list(GROUPS), help="default: cum D NNLS Reg (RegAlpha = alpha 0.05 and 0.1 is opt-in)")
    ap.add_argument("--stages", nargs="*", type=int, default=[0, 1, 2])
    ap.add_argument("--no-stop-rule", action="store_true", help="run s = 2 for every cell, also where the s = 1 correct-count rate is < 10 %")
    ap.add_argument("--name", default="main")
    ap.add_argument("--round1", type=int, default=ROUND1_REPS, help="replicates in stage 1")
    ap.add_argument("--round2", type=int, default=ROUND2_REPS, help="replicates after the extension (stage 2)")
    ap.add_argument("--cum-reps", type=int, default=CUM_REPS, help="replicates for B, C2, C4")
    ap.add_argument("--levels", nargs="*", type=float, default=None, help="noisy levels of stage 1 (default 1 2)")
    a = ap.parse_args()
    ROUND1_REPS, ROUND2_REPS, CUM_REPS = a.round1, a.round2, a.cum_reps
    if a.levels:
        LEVELS = tuple(a.levels)
    if a.cmd == "collect":
        cmd_collect([a.name])
    else:
        print("system kept awake (idle sleep blocked while running):", keep_system_awake(), flush=True)
        run_main(a)


if __name__ == "__main__":
    main()
