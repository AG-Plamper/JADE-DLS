# -*- coding: utf-8 -*-
"""
make_monomodal_tables.py -- summary tables of the monomodal samples (25, 50 and 100 nm), from the evaluated runs.

    python code/make_monomodal_tables.py

Reads data/records/records_main.csv (50 nm) and records_sizes.csv (25 and 100 nm) (written by `run_study.py collect`). Writes
  results/1_monomodal/all_methods_summary.csv   per size, true PDI, noise level and method: runs, correct-count and success rate (%), mean and sd of the relative
                                                deviation of Rh from the true z-average (%), fitted PDI (mean, sd) and mean number of populations
  results/1_monomodal/pdi_recovery.csv          fitted against true PDI (C2, C4, Method D) per size, true PDI and noise level
PDI = relative variance of the decay-rate distribution (mu2 / Gamma_mean^2); the true value is the relative variance of the generating lognormal.
Method B has no PDI; NNLS and the regularized fit report none.
"""
import re

import numpy as np
import pandas as pd

import paths as P

CUMU = {"B", "C2", "C4"}
PDI_METHODS = ["C2", "C4", "D"]


def load():
    parts = [pd.read_csv(P.records(n)) for n in ("main", "sizes") if P.records(n).exists()]
    d = pd.concat(parts, ignore_index=True)
    d = d[d.geometry.str.startswith("mono") & d.error.isna()].copy()
    d["rh_nm"] = d.geometry.map(lambda g: float(re.search(r"rh([0-9]+)", g).group(1)) if "_rh" in g else 50.0)
    d["pdi_true"] = d.geometry.map(lambda g: float(re.search(r"pdi([0-9.]+)", g).group(1)))
    # relative Rh deviation from the true z-average Rh, in %: apparent Rh (cumulants) or the single found peak
    d["dev_pct"] = 100 * np.where(d.method.isin(CUMU), d.rel_err_z, d.rel_err_1)
    return d


def all_methods_summary(d):
    out = []
    for (rh, p, lv, m), g in d.groupby(["rh_nm", "pdi_true", "noise_level", "method"]):
        out.append({"rh_true_nm": rh, "pdi_true": p, "noise_level": lv, "method": m, "n_runs": len(g),
                    "count_ok_pct": 100 * g.count_ok.astype(float).mean(),
                    "success_pct": 100 * g.success.astype(float).mean(),
                    "rh_dev_mean_pct": g.dev_pct.mean(), "rh_dev_sd_pct": g.dev_pct.std(ddof=1),
                    "pdi_mean": g.pdi.mean() if g.pdi.notna().any() else np.nan,
                    "pdi_sd": g.pdi.std(ddof=1) if g.pdi.notna().sum() > 1 else np.nan,
                    "n_populations_mean": g.n_found.mean()})
    return pd.DataFrame(out)


def pdi_recovery():
    parts = [pd.read_csv(P.records(n)) for n in ("main", "sizes") if P.records(n).exists()]
    d = pd.concat(parts, ignore_index=True)
    d = d[d.geometry.str.startswith("mono") & d.method.isin(PDI_METHODS) & d.pdi.notna()].copy()
    d["pdi_true"] = d.geometry.map(lambda g: float(re.search(r"pdi([0-9.]+)", g).group(1)))
    d["rh_true_nm"] = d.geometry.map(lambda g: float(re.search(r"rh([0-9]+)", g).group(1)) if "_rh" in g else 50.0)
    rows = []
    for (rh, pt, lv, m), g in d.groupby(["rh_true_nm", "pdi_true", "noise_level", "method"]):
        x = g.pdi.astype(float)
        rows.append({"rh_true_nm": rh, "pdi_true": pt, "noise_level": lv, "method": m, "n_runs": len(x), "pdi_mean": x.mean(),
                     "pdi_sd": x.std(ddof=1) if len(x) > 1 else float("nan"), "pdi_median": x.median(),
                     "bias_pct": 100 * (x.mean() / pt - 1),
                     "n_populations_mean": g.n_found.mean()})
    return pd.DataFrame(rows)


def main():
    all_methods_summary(load()).to_csv(P.table("1_monomodal", "all_methods_summary.csv"), index=False)
    t = pdi_recovery()
    t.to_csv(P.table("1_monomodal", "pdi_recovery.csv"), index=False)
    pd.set_option("display.width", 200)
    print(t.round(3).to_string(index=False))


if __name__ == "__main__":
    main()
