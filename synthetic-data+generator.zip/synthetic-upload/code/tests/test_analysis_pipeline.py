# -*- coding: utf-8 -*-
"""Tests of the pipeline pieces: tokens, curation, analytic gradient, runner helpers."""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE.parent.parent))

import simulate_data  # noqa: E402
import analysis_pipeline as pl  # noqa: E402
import fast_regularized_fit  # noqa: E402
import run_study as rs  # noqa: E402


def test_parse_token():
    assert pl.parse_token("D") == ("D", {})
    assert pl.parse_token("D:gap=3.0") == ("D", {"gap": 3.0})
    assert pl.parse_token("Reg:alpha=0.05") == ("Reg", {"alpha": 0.05})
    s = pl._settings_for(pl.Settings(), "Reg", {"alpha": 0.05})
    assert s.reg_alpha == 0.05 and pl.Settings().reg_alpha == 0.2
    assert pl._settings_for(pl.Settings(), "D", {"gap": 3.0}).d_gap_threshold == 3.0
    assert pl._settings_for(pl.Settings(), "NNLS", {"points": 200.0}).nnls_points == 200.0
    assert pl.parse_token("NNLS:points=50,prom=0.1") == ("NNLS", {"points": 50.0, "prom": 0.1})


def _table():
    nan = np.nan
    rows = [
        # two clearly separated peaks (valley 2 %)           -> keep
        dict(filename="a", tau_1=1e-3, tau_2=2e-2, valley_1=0.02),
        # two overlapping peaks (valley 30 %)                -> drop
        dict(filename="b", tau_1=1e-3, tau_2=2e-2, valley_1=0.30),
        # single peak                                        -> keep
        dict(filename="c", tau_1=5e-3, tau_2=nan, valley_1=nan),
        # duplicate peaks with the same centroid             -> keep, duplicate blanked
        dict(filename="d", tau_1=5e-3, tau_2=5.01e-3, valley_1=0.97),
        # valley exactly at the limit                        -> keep
        dict(filename="e", tau_1=1e-3, tau_2=3e-2, valley_1=0.05),
    ]
    df = pd.DataFrame(rows)
    df["gamma_1"], df["gamma_2"] = 1 / df["tau_1"], 1 / df["tau_2"]
    return df


def test_curate_keeps_cleanly_separated_files():
    s = pl.Settings()
    cur, n = pl.curate(_table(), s)
    assert n == 4
    assert list(cur["filename"]) == ["a", "c", "d", "e"]
    assert np.isnan(cur.loc[cur.filename == "d", "gamma_2"]).all()      # duplicate blanked
    assert np.isfinite(cur.loc[cur.filename == "a", "gamma_2"]).all()
    s2 = pl.Settings(valley_max=0.5)
    assert pl.curate(_table(), s2)[1] == 5


def test_curated_result_unresolved_when_too_few_files():
    res = pl.cluster_from_table("Reg", _table(), 1.0, pl.Settings(), curated=True)
    assert res["method"] == "Reg-cur" and res["n_found"] == 0           # 4 files kept < min_files = 6
    assert res["extra"] == {"files_kept": 4, "files_total": 5}


def test_analytic_gradient_matches_finite_differences():
    """fast_regularized_fit's gradient equals scipy's finite-difference gradient of nnls_reg's own objective."""
    import regularized as rg
    from scipy.optimize._numdiff import approx_derivative
    ds = simulate_data.simulate([(25, 0.05, 0.5), (100, 0.05, 0.5)], noise_level=1, noise_mode="correlated",
                        seed=2, angles=(90,), runs=1)
    df = next(iter(ds.processed_correlations().values()))
    df = df.assign(weight=np.linspace(0.5, 1.5, len(df)))
    captured = {}

    def grab(fun, x0, *a, **k):
        captured["fun"], captured["x0"] = fun, x0
        raise RuntimeError("captured")

    par = {"decay_times": np.logspace(-8, 1, 60), "prominence": 0.005, "distance": 1, "alpha": 0.2,
           "fit_beta": True, "normalize": True, "peak_method": "centroid", "sparsity_penalty": 0}
    orig = rg.minimize
    rg.minimize = grab
    try:
        with pytest.raises(RuntimeError):
            rg.nnls_reg(df, "a", par, 1)
    finally:
        rg.minimize = orig
    jac = fast_regularized_fit._reg_jac(captured["fun"])
    assert jac is not None
    rng = np.random.default_rng(0)
    x = np.concatenate([[0.9], rng.uniform(0.05, 1.0, 60)])
    num = approx_derivative(captured["fun"], x, method="3-point")
    assert np.allclose(jac(x), num, rtol=1e-4, atol=1e-9 * np.abs(num).max())


def test_fast_regularized_fit_is_reversible():
    import regularized as rg
    orig = rg.minimize
    fast_regularized_fit.enable()
    assert rg.minimize is not orig and fast_regularized_fit.is_enabled()
    fast_regularized_fit.disable()
    assert rg.minimize is orig and not fast_regularized_fit.is_enabled()


def test_stop_rule_helpers():
    stats = {"D": (10, 0), "D:gap=3": (10, 2)}
    assert rs.best_rate(stats) == pytest.approx(0.2)
    assert rs.is_uncertain(stats)
    assert not rs.is_uncertain({"D": (10, 0), "NNLS": (10, 10)})
    assert rs.best_rate({"D": (10, 0)}) == 0
    # cumulants: reduced set + (since 2026-11-02) the unequal-intensity samples *_i80 / *_i20
    assert rs.group_geometries("cum", list(simulate_data.geometries())) == simulate_data.cumulant_geometries() + [
        g for g in simulate_data.geometries() if g.endswith(("_i80", "_i20"))]


def test_regularised_fit_end_to_end_with_curation():
    """Noise-free 10:1 bimodal: both populations found, curation keeps the files, Rh within 20 %."""
    ds = simulate_data.simulate([(50 / 10 ** 0.5, 0.05, 0.5), (50 * 10 ** 0.5, 0.05, 0.5)], noise_level=0, seed=1,
                        angles=tuple(range(30, 151, 20)), runs=1)
    res = pl.analyze_dataset(ds, methods=("Reg",))
    assert set(res) == {"Reg", "Reg-cur"}
    for name in ("Reg", "Reg-cur"):
        assert res[name]["error"] is None
        assert res[name]["n_found"] == 2
        ev = pl.evaluate(res[name], ds.truth)
        assert ev["success"]
    assert res["Reg-cur"]["extra"]["files_kept"] >= 6
    assert "table" in res["Reg"] and len(res["Reg"]["table"]) == 7
    # the stored table reproduces the result offline
    again = pl.cluster_from_table("Reg", res["Reg"]["table"], pl.c_constant(ds.df_basedata), pl.Settings())
    assert again["n_found"] == res["Reg"]["n_found"]
    assert again["rh"] == pytest.approx(res["Reg"]["rh"])


def test_d_tables_match_module_function():
    """analysis_pipeline.d_table (one Dirac fit per file, grouped afterwards for any gap) reproduces
    cumulants_D.fit_correlations_method_D exactly."""
    from cumulants_D import fit_correlations_method_D
    ds = simulate_data.simulate([(50 / 3 ** 0.5, 0.05, 0.5), (50 * 3 ** 0.5, 0.05, 0.5)], noise_level=1,
                        noise_mode="correlated", seed=1, angles=(60, 90, 120), runs=1)
    with pl._quiet():
        pc = pl.prepare(ds.processed_correlations(), ds.df_basedata, True)
        fits = pl.d_fit_files(pc, pl.Settings())
        for gap in (2.0, 3.0):
            mine = pl.d_table(fits, ds.df_basedata, gap).sort_values("filename").reset_index(drop=True)
            ref = fit_correlations_method_D(pc, n_max=25, n_start=1, gap_threshold=gap, plot=False)
            ref = pl._merge(ds.df_basedata, ref).sort_values("filename").reset_index(drop=True)
            for col in ("n_modes", "n_populations", "gamma_1", "gamma_2", "gamma_mean", "pdi", "R-squared"):
                assert np.allclose(mine[col].astype(float), ref[col].astype(float), equal_nan=True, rtol=1e-12)
