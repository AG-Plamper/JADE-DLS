import os
os.environ["MPLBACKEND"] = "Agg"   # tests must never open figure windows
