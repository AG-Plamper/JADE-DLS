# -*- coding: utf-8 -*-
"""
make_parameter_sensitivity_tables.py -- sensitivity of NNLS and the regularized fit to their settings (bimodal samples of size ratios 2 to 10 and monomodal 50 nm).

    python code/make_parameter_sensitivity_tables.py

Reads the stored per-file results data/raw/{main,i20,nnlsvar,nnlsprom,nnlsp05,regalpha,regvar} (written by run_study.py; nothing is refitted) and the evaluated
runs data/records/records_{main,regalpha}.csv. Writes (success = correct number of populations and every Rh within +-20 %)
  results/4_parameter_sensitivity/nnls_grid_prominence.csv         NNLS with 50 / 100 (default) / 200 grid points and peak prominence 0.01 (default) / 0.05 / 0.1 / 0.2:
                                                                   per sample, noise level and setting: runs, correct-count runs, successful runs
  results/4_parameter_sensitivity/regularized_alpha.csv            regularized fit with alpha = 0.05, 0.1, 0.2 (default), all files and curated: per sample, noise level,
                                                                   alpha and variant: correct-count and success rate, mean number of populations, median Rh errors
  results/4_parameter_sensitivity/regularized_grid_prominence.csv  regularized fit with 100 / 200 (default) grid points and prominence 0.005 (default) / 0.02 / 0.05:
                                                                   per sample, noise level and setting: runs, correct-count runs, successful runs
Method D at many gap thresholds: sweep_method_D_gap.py (same folder).
"""
import json

import numpy as np
import pandas as pd

import paths as P

RAW = P.RAW
RATIOS = (2.0, 3.0, 5.0, 7.0, 10.0)
SPLITS = ("", "_i80", "_i20")
PDIS = (0.05, 0.1, 0.2)
LEVELS = (0.0, 1.0, 2.0)
KEY_SUFFIX = {0.0: "s0_white", 1.0: "s1_correlated", 2.0: "s2_correlated"}


def sample_order():
    """order of the rows: noise level, population PDI, then bimodal samples (size ratio, split), then the monomodal samples"""
    for level in LEVELS:
        for pdi in PDIS:
            yield level, [f"bi_r{r:g}_pdi{pdi:g}{suf}" for r in RATIOS for suf in SPLITS]
    for level in LEVELS:
        yield level, [f"mono_pdi{pdi:g}" for pdi in PDIS]


def cell(geom, level, label, token, runs):
    return {"geometry": geom, "noise_level": level, "variant": token, "axis_value": label, "n": len(runs),
            "count_ok": sum(q[1] for q in runs), "success": sum(q[2] for q in runs)}


# ----------------------------------------------------------------------------- NNLS
# (axis value, token); the default NNLS (100 points, prominence 0.01) is stored in the sets main / i20
NNLS_VARIANTS = [("50", "NNLS:points=50"), ("100", "NNLS"), ("200", "NNLS:points=200"),
                 ("0.01", "NNLS"), ("0.05", "NNLS:prom=0.05"), ("0.1", "NNLS:prom=0.1"), ("0.2", "NNLS:prom=0.2")]


def nnls_runs(geom, level, token):
    """-> list of (rh list, count_ok, success, truth) over the replicates."""
    reps = [0] if level == 0 else range(10)
    out = []
    for rep in reps:
        key = f"{geom}__{KEY_SUFFIX[level]}_r{rep:03d}"
        if token == "NNLS":
            p = next((RAW / f / f"{key}_NNLS_w.json" for f in ("main", "i20") if (RAW / f / f"{key}_NNLS_w.json").exists()), None)
        else:
            folder, group = {"NNLS:prom=0.05": ("nnlsp05", "NNLSp05"), "NNLS:prom=0.2": ("nnlsprom", "NNLSprom")}.get(token, ("nnlsvar", "NNLSvar"))
            p = RAW / folder / f"{key}_{group}_w.json"
            p = p if p.exists() else None
        if p is None:
            continue
        r = json.loads(p.read_text(encoding="utf-8"))
        res, ev = r["results"].get(token), r["eval"].get(token)
        if not res or res.get("error") or ev is None:
            out.append(([], False, False, r["truth"]["rh_pops"]))
            continue
        out.append((sorted(res["rh"]), bool(ev["count_ok"]), bool(ev["success"]), r["truth"]["rh_pops"]))
    return out


def nnls_grid_prominence():
    cells = []
    for level, geoms in sample_order():
        for geom in geoms:
            data = {v: nnls_runs(geom, level, v[1]) for v in NNLS_VARIANTS}
            if not any(data.values()):
                continue
            for (label, token), runs in data.items():
                if runs:
                    default_label = "NNLS" if geom.startswith("mono") else "NNLS default"      # the default setting appears on both axes (100 points, prominence 0.01)
                    cells.append({"geometry": geom, "noise_level": level, "variant": token if label in ("50", "200") or token != "NNLS" else default_label,
                                  "axis_value": label, "n": len(runs), "count_ok": sum(q[1] for q in runs), "success": sum(q[2] for q in runs)})
    return pd.DataFrame(cells)


# ----------------------------------------------------------------------------- regularized fit, grid points and prominence
DEFAULT = [("main", "Reg"), ("i20", "Reg")]
REG_GRID = [("100", "Reg:points=100", [("regvar", "RegVar")]), ("200", "Reg", DEFAULT),
            ("0.005", "Reg", DEFAULT), ("0.02", "Reg:prom=0.02", [("regvar", "RegVar")]), ("0.05", "Reg:prom=0.05", [("regvar", "RegVar")])]


def reg_runs(geom, level, token, sources):
    out = []
    for rep in ([0] if level == 0 else range(10)):
        key = f"{geom}__{KEY_SUFFIX[level]}_r{rep:03d}"
        p = next((RAW / f / f"{key}_{g}_w.json" for f, g in sources if (RAW / f / f"{key}_{g}_w.json").exists()), None)
        if p is None:
            continue
        r = json.loads(p.read_text(encoding="utf-8"))
        res, ev = r["results"].get(token), r["eval"].get(token)
        if not res or res.get("error") or ev is None:
            out.append(([], False, False, r["truth"]["rh_pops"]))
            continue
        out.append((sorted(res["rh"]), bool(ev["count_ok"]), bool(ev["success"]), r["truth"]["rh_pops"]))
    return out


def regularized_grid_prominence():
    cells = []
    for level, geoms in sample_order():
        for geom in geoms:
            data = [reg_runs(geom, level, token, src) for _, token, src in REG_GRID]
            if not any(data):
                continue
            for (label, token, _), runs in zip(REG_GRID, data):
                if runs:
                    cells.append(cell(geom, level, label, token, runs))
    return pd.DataFrame(cells)


# ----------------------------------------------------------------------------- regularized fit, regularization parameter
def regularized_alpha():
    a = pd.read_csv(P.records("regalpha"))
    m = pd.read_csv(P.records("main"))
    m = m[m.method.isin(["Reg", "Reg-cur"])].copy()
    m["method"] = m.method.map({"Reg": "Reg:alpha=0.2", "Reg-cur": "Reg:alpha=0.2-cur"})
    d = pd.concat([a, m], ignore_index=True)
    d = d[d.method.str.startswith("Reg:alpha") & d.error.isna()].copy()
    d["alpha"] = d.method.str.extract(r"alpha=([0-9.]+)")[0].astype(float)
    d["variant"] = np.where(d.method.str.endswith("-cur"), "curated", "all files")
    d["pdi"] = d.geometry.str.extract(r"pdi([0-9.]+)")[0].astype(float)
    d["mono"] = d.geometry.str.startswith("mono")
    d = d[d.pdi.isin([0.05, 0.1]) | d.mono]
    rows = []
    for (g, lv, al, var), x in d.groupby(["geometry", "noise_level", "alpha", "variant"]):
        r = {"geometry": g, "noise_level": lv, "alpha": al, "variant": var, "n_runs": len(x),
             "count_ok": x.count_ok.astype(float).mean(), "success": x.success.astype(float).mean(),
             "n_found_mean": x.n_found.mean()}
        ok = x[x.count_ok.astype(bool)]
        for i in (1, 2):
            v = ok[f"rel_err_{i}"].dropna() if f"rel_err_{i}" in ok else pd.Series(dtype=float)
            r[f"rel_err_{i}_median_pct"] = 100 * v.median() if len(v) else np.nan
        rows.append(r)
    return pd.DataFrame(rows)


def main():
    nnls = nnls_grid_prominence()
    nnls.to_csv(P.table("4_parameter_sensitivity", "nnls_grid_prominence.csv"), index=False)
    alpha = regularized_alpha()
    alpha.to_csv(P.table("4_parameter_sensitivity", "regularized_alpha.csv"), index=False)
    grid = regularized_grid_prominence()
    grid.to_csv(P.table("4_parameter_sensitivity", "regularized_grid_prominence.csv"), index=False)
    print("rows: nnls", len(nnls), "| regularized alpha", len(alpha), "| regularized grid / prominence", len(grid))


if __name__ == "__main__":
    main()
