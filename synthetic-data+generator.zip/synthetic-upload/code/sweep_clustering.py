# -*- coding: utf-8 -*-
"""
sweep_clustering.py -- performance of the cross-file clustering (distance threshold, minimum abundance, strategy) on ALL stored fit tables.

    python code/sweep_clustering.py [--jobs 14] [--levels 0 1 2]

Final analysis step of the synthetic study. Nothing is refitted: the stored per-file tables of the default settings of Method D (gap 2.0),
NNLS (100 points, prominence 0.01) and the regularised fit (alpha 0.2, 200 points, prominence 0.005, all files) are clustered again with other settings (analysis_pipeline.cluster_from_table) for the 48 samples (monomodal 50 nm + 45 bimodal) at
s = 0 (1 data set), s = 1 and s = 2 (first 10 replicates). Grid: distance 0.5 / 1.0 / 1.5 / 2.0 / 3.0 / 4.0 x minimum abundance 0.1 / 0.3 / 0.5
with the default strategy (silhouette_refined), plus the strategy 'simple' at the defaults (2.0, 0.3) and at distance 1.5 / 3.0.
Defaults of the study: distance 2.0, minimum abundance 0.3, silhouette_refined.
The NNLS setting added in the final analysis (prominence 0.1, 100 points; label NNLS-p0.1, raw/nnlsvar) was added afterwards.
Writes results/5_clustering_sensitivity/mono_bimodal_runs_<method>.csv (one row per run and setting, one file per method; an existing file is not recomputed)
and the pooled table mono_bimodal.csv (count-correct and success rate per method, kind, noise level, strategy, distance and minimum abundance = mean of these rows).
"""
import argparse
import contextlib
import io
import json
import os
import sys
import warnings
from pathlib import Path

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "1")
os.environ["MPLBACKEND"] = "Agg"
HERE = Path(__file__).resolve().parent
import paths as P  # noqa: E402  (locations of data, results, ...)
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(P.ROOT))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

RAW = P.RAW
DISTANCES = (0.5, 1.0, 1.5, 2.0, 3.0, 4.0)
MIN_ABUNDANCES = (0.1, 0.3, 0.5)
GRID = [(d, m, "silhouette_refined") for d in DISTANCES for m in MIN_ABUNDANCES] + [(2.0, 0.3, "simple"), (1.5, 0.3, "simple"), (3.0, 0.3, "simple")]
GEOMS = ([f"mono_pdi{p}" for p in ("0.05", "0.1", "0.2")]
         + [f"bi_r{r}_pdi{p}{s}" for r in ("2", "3", "5", "7", "10") for p in ("0.05", "0.1", "0.2") for s in ("", "_i80", "_i20")])
KEY = {0: "s0_white", 1: "s1_correlated", 2: "s2_correlated"}
# label -> (table method, folders (first hit wins), group, token inside the file)
METHODS = {"D": ("D", ("main", "i20"), "D", "D"),
           "NNLS": ("NNLS", ("main", "i20"), "NNLS", "NNLS"),
           "NNLS-p0.1": ("NNLS", ("nnlsvar",), "NNLSvar", "NNLS:prom=0.1"),   # NNLS setting of the final analysis (100 points, prominence 0.1)
           "Reg": ("Reg", ("main", "i20"), "Reg", "Reg")}


def find(geom, level, rep, folders, group):
    for folder in folders:
        p = RAW / folder / f"{geom}__{KEY[level]}_r{rep:03d}_{group}_w.json"
        if p.exists():
            return p
    return None


def one(label, geom, level, rep):
    warnings.simplefilter("ignore")
    import analysis_pipeline as pl
    import simulate_data
    method, folders, group, token = METHODS[label]
    p = find(geom, level, rep, folders, group)
    if p is None:
        return []
    r = json.loads(p.read_text(encoding="utf-8"))
    res0 = r["results"].get(token)
    if not res0 or not res0.get("table"):
        return []
    c = pl.c_constant(simulate_data.simulate([(50.0, 0.05, 1.0)], noise_level=0, seed=0).df_basedata)
    out = []
    for dist, ma, strat in GRID:
        s = pl.Settings(cluster_distance=dist, cluster_min_abundance=ma, cluster_strategy=strat)
        rec = {"method": label, "geometry": geom, "level": level, "rep": rep, "distance": dist, "min_abundance": ma, "strategy": strat}
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                res = pl.cluster_from_table(method, res0["table"], c, s, curated=False)
            ev = pl.evaluate(res, r["truth"])
            rec.update(n_found=res["n_found"], count_ok=bool(ev["count_ok"]), success=bool(ev["success"]),
                       rh="; ".join(f"{x:.1f}" for x in res["rh"]))
        except Exception as e:
            rec.update(n_found=np.nan, count_ok=False, success=False, rh="", error=f"{type(e).__name__}: {e}")
        out.append(rec)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=14)
    ap.add_argument("--levels", nargs="*", type=int, default=[0, 1, 2])
    ap.add_argument("--methods", nargs="*", default=list(METHODS), choices=list(METHODS))
    a = ap.parse_args()
    from joblib import Parallel, delayed
    for label in a.methods:
        out = P.table("5_clustering_sensitivity", f"mono_bimodal_runs_{label}.csv")
        if out.exists():
            print(label, "exists - skipped", flush=True)
            continue
        tasks = [(label, g, lv, rep) for g in GEOMS for lv in a.levels for rep in ([0] if lv == 0 else range(10))]
        print(f"=== {label}: {len(tasks)} data sets x {len(GRID)} settings", flush=True)
        res = Parallel(n_jobs=a.jobs, batch_size=4, verbose=2)(delayed(one)(*t) for t in tasks)
        df = pd.DataFrame([x for r in res for x in r])
        df.to_csv(out, index=False)
        print(label, "->", out.name, len(df), "rows; errors:", int(df["error"].notna().sum()) if "error" in df else 0, flush=True)
    summarize()


def summarize():
    """pooled table over all methods whose per-run file exists: count-correct and success rate per method, kind, noise level, strategy, distance, minimum abundance."""
    parts = [pd.read_csv(P.table("5_clustering_sensitivity", f"mono_bimodal_runs_{m}.csv")) for m in METHODS
             if P.table("5_clustering_sensitivity", f"mono_bimodal_runs_{m}.csv").exists()]
    d = pd.concat(parts, ignore_index=True)
    d["kind"] = np.where(d.geometry.str.startswith("mono"), "mono", "bi")
    summ = (d.groupby(["method", "kind", "level", "strategy", "distance", "min_abundance"])
              .agg(n=("count_ok", "size"), count_ok=("count_ok", "mean"), success=("success", "mean")).reset_index())
    summ.to_csv(P.table("5_clustering_sensitivity", "mono_bimodal.csv"), index=False)
    print("summary written", len(summ), "rows")


if __name__ == "__main__":
    main()
