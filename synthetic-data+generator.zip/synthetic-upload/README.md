# Synthetic-data benchmark for JADE-DLS

Simulated DLS measurements with known size distributions (ALV lag grid, 13 angles x 3 runs, noise with a Biganzoli-Ferri variance and correlation between neighbouring lags) are analysed with the methods of JADE-DLS (cumulants B, C2, C4, Method D, NNLS, regularized fit, cross-file clustering) and compared with the truth. Samples: monomodal (25, 50, 100 nm), bimodal (size ratios 2 to 10, three intensity splits) and trimodal, each with PDI 0.05, 0.10 and 0.20, at noise levels s = 0 (noise-free), 1 and 2, plus variations of the method settings.

**Frozen on JADE-DLS v3.0.** The results were produced with the v3.0 analysis modules. Later versions (3.1 and above) are not used here and can give different numbers.

Tested environment (the one that produced the results): Python 3.12.12, NumPy 1.26.4, SciPy 1.15.3, pandas 2.2.3, scikit-learn 1.5.1, statsmodels 0.14.4, joblib 1.5.2, matplotlib 3.10.0, pytest 9.2.0.

## Map: topic, tables, producing script

All scripts are in `code/`; `run_study.py` runs the simulations and analyses, the `make_*` scripts compute tables from the stored runs, the `sweep_*` scripts re-evaluate stored fits with other settings, the `check_*` scripts test assumptions.

| topic | table (`results/<folder>/`) | script | figures (`figures/`) |
|---|---|---|---|
| **0_run_summaries/** all runs | `<set>.csv` (one per data set, see below) | `run_study.py collect` | |
| **1_monomodal/** | `all_methods_summary.csv`, `pdi_recovery.csv` | `make_monomodal_tables.py` | `cumulants.pdf` |
| | `cumulants.csv` | `make_cumulant_tables.py` | |
| **2_bimodal/** | `success_by_intensity_split.csv`, `method_combinations.csv`, `decision_rules_flagged.csv` | `make_bimodal_tables.py` | `overview_default_settings.pdf`, `cumulants.pdf` |
| | `cumulants.csv` | `make_cumulant_tables.py` | |
| **3_trimodal/** | `success_by_sample.csv`, `summary.csv`, `decision_rules_flagged.csv` | `make_trimodal_tables.py` | `3_trimodal.pdf`, `overview_default_settings.pdf`, `cumulants.pdf` |
| | `cumulants.csv` | `make_cumulant_tables.py` | |
| **4_parameter_sensitivity/** | `method_D_gap.csv`, `method_D_gap_split20-80.csv` | `sweep_method_D_gap.py` | `4_method_D_gap.pdf` |
| | `nnls_grid_prominence.csv`, `regularized_alpha.csv`, `regularized_grid_prominence.csv` | `make_parameter_sensitivity_tables.py` | `4_nnls_variations.pdf`, `4_regularized_alpha.pdf`, `4_regularized_grid.pdf` |
| **5_clustering_sensitivity/** | `mono_bimodal.csv` | `sweep_clustering.py` | `5_clustering.pdf` |
| | `trimodal.csv` | `sweep_clustering_trimodal.py` | |
| **6_noise_model_check/** real gold-particle data against the noise model | `descriptive.csv`, `noise_level.csv`, `lag_correlation.csv` | `check_noise_model_gold.py` | |
| **checks/** | `fast_regularized_fit.csv` | `check_fast_regularized_fit.py` | |

Core modules: `simulate_data.py` (simulator), `analysis_pipeline.py` (the JADE-DLS workflow without notebook), `fast_regularized_fit.py` (analytic gradient for the regularized fit), `evaluate_runs.py` (collects and summarizes runs), `paths.py` (locations). `data/input/` holds the lag grid of the simulator. The figure PDFs have one page per sample or parameter setting.

## Quick start

1. Check out **JADE-DLS v3.0** and copy this folder into its root (for example as `synthetic/`). The scripts import the analysis modules (`cumulants*.py`, `regularized.py`, `clustering.py`, `weighting.py`, `preprocessing.py`) from the parent folder, which must therefore be the v3.0 repository root. Install the JADE-DLS dependencies plus `joblib` and `pytest`.
2. Run the tests:

   ```bash
   python -m pytest code/tests -q
   ```

3. Regenerate the data (seeds depend only on the sample and the replicate index; runs are resumable):

   ```bash
   python code/run_study.py main --name main --jobs 8     # raw fit results -> data/raw/main/
   python code/run_study.py collect --name main           # -> data/records/records_main.csv, results/0_run_summaries/main.csv
   ```

   The per-file fit results (`data/raw/`) and the per-run records (`data/records/`) are not part of the repository; the tables in `results/` are computed from them.

4. Recompute the tables, for example:

   ```bash
   python code/make_monomodal_tables.py
   python code/make_bimodal_tables.py
   ```

**Run time.** The full study is about 37,000 evaluations (25,000 stored per-file result sets; every sample, noise level, replicate and method group is one task) and takes several days on a multi-core machine. Subsets: `--geoms` selects samples, `--groups` selects method groups, `--stages` the replicate stages, e.g. `--geoms bi_r5_pdi0.1 --groups D NNLS --stages 0 1`.

## Details

### Data sets (`--name`) and their samples

`python code/run_study.py --help` lists all options: `--geoms`, `--groups`, `--name`, `--stages`, `--no-stop-rule`, `--cum-reps`. Default: groups C2/C4, D, NNLS and Reg; stage 0 noise-free, stage 1 with 10 replicates at s = 1 and 2, stage 2 extension to 30 replicates where the result is still undecided.

| set (`--name`) | samples (`code/simulate_data.py`) | tables computed from it |
|---|---|---|
| `main` | `geometries()`: monomodal 50 nm, bimodal 50/50 and 80/20 | monomodal, bimodal, trimodal comparison, parameter sensitivity, clustering |
| `i20` | `i20_geometries()`: bimodal 20/80 | bimodal, parameter sensitivity |
| `sizes` | `size_geometries()`: monomodal 25 and 100 nm | monomodal |
| `tri` | `trimodal_geometries()` | trimodal |
| `cumtab` | `cumulant_geometries()` with `--groups cum B --cum-reps 10 --no-stop-rule` | cumulants, flagged runs (bimodal) |
| `nnlsvar`, `nnlsprom`, `nnlsp05` | NNLS with other grid and prominence settings (groups `NNLSvar`, `NNLSprom`, `NNLSp05`) | parameter sensitivity |
| `regalpha`, `regvar` | regularized fit with other regularization parameters (`RegAlpha`, `RegAlpha4`) and other grid / prominence settings (`RegVar`) | parameter sensitivity, bimodal |

The default sample grid also contains the size ratios 1.5 and 4; they are not part of the evaluated results (ratios 2, 3, 5, 7 and 10).

### What the tables contain

| table | content |
|---|---|
| `0_run_summaries/<set>.csv` | per sample, noise level and method: number of runs, rate of the correct number of populations, success rate (correct number and all radii within ±20 %, with Wilson intervals), radius bias and spread, PDI |
| `1_monomodal/all_methods_summary.csv` | rates and radii per size, PDI, noise level and method |
| `1_monomodal/pdi_recovery.csv` | fitted against true PDI (C2, C4, Method D) |
| `*/cumulants.csv` | cumulant methods B, C2, C4 per topic: error against the z-average, fitted PDI against true PDI, Gamma-q² intercept (computed from `cumtab` for monomodal and bimodal, `tri` for trimodal) |
| `2_bimodal/success_by_intensity_split.csv` | resolution limits of D, NNLS and the regularized fit for the three intensity splits (runs, successes, radius errors per cell) |
| `2_bimodal/method_combinations.csv` | share of runs with full success / with both radii found, per method and for combinations of the three multimodal methods |
| `*/decision_rules_flagged.csv` | decision rules (single method, average, consensus, majority) for runs flagged as multimodal by the cumulant fit (fitted PDI of C2 above 0.3) |
| `3_trimodal/success_by_sample.csv`, `summary.csv` | count-correct and success rates and recovery of each true population, per sample (`success_by_sample`) and pooled over the PDI (`summary`) |
| `4_parameter_sensitivity/method_D_gap*.csv` | Method D at many gap thresholds, per run |
| `4_parameter_sensitivity/nnls_grid_prominence.csv`, `regularized_grid_prominence.csv` | runs, correct-count and successful runs for other grid-point and prominence settings |
| `4_parameter_sensitivity/regularized_alpha.csv` | regularized fit with other regularization parameters (all files and curated) |
| `5_clustering_sensitivity/mono_bimodal.csv`, `trimodal.csv` | count-correct and success rates for the distance threshold, minimum abundance and strategy of the cross-file clustering (the per-run rows are written next to them as `*_runs_<method>.csv` when the scripts run) |
| `6_noise_model_check/*.csv` | the real 30 nm + 200 nm gold mixture against the assumptions of the simulation: coherence factor, baseline, noise level, lag-to-lag correlation (`--analyse` adds the results of the methods on the real files) |
| `checks/fast_regularized_fit.csv` | fast regularized fit against the module of JADE-DLS on 324 simulated curves (the run-time columns depend on the machine) |

### Commands of the other scripts

They work on the stored fit tables (no refit) or on the records of the respective sets (`data/raw/`, `data/records/`):

```bash
python code/make_cumulant_tables.py
python code/make_parameter_sensitivity_tables.py
python code/make_trimodal_tables.py
python code/sweep_method_D_gap.py                                                  # sets main and sizes
python code/sweep_method_D_gap.py --sets i20 --out method_D_gap_split20-80.csv
python code/sweep_clustering.py --levels 0 1 2
python code/sweep_clustering_trimodal.py --levels 1
python code/check_noise_model_gold.py [--analyse]                                  # needs the gold data of the repository
python code/check_fast_regularized_fit.py
```

### Writing simulated data as ALV `.ASC` files

JADE-DLS reads the files like measured data (13 angles x 3 runs = 39 files):

```python
import sys
sys.path.insert(0, "code")
import simulate_data

# populations: (Rh in nm, PDI, intensity fraction); noise_level s = 0 (noise-free), 1, 2; the seed fixes the data set
ds = simulate_data.simulate([(30, 0.05, 0.5), (90, 0.05, 0.5)], noise_level=1, noise_mode="correlated", seed=7)
simulate_data.write_asc(ds, "asc_example")     # writes the .ASC files into the folder asc_example/
```

`simulate` also takes the angles, the number of runs per angle and an optional sphere form factor (`form_factor="sphere"`); see its docstring.

### Notes

- The noise model is an assumption (Biganzoli-Ferri variance times an AR(1)-type correlation between neighbouring lags with an assumed profile); its magnitude was checked against the residuals of real gold measurements (`6_noise_model_check/`).
- The method settings are those of the JADE-DLS notebook; the runs use no per-sample tuning.
- Reproduction check (v3.0 modules, stored per-file results): every table in `results/1_monomodal` to `results/6_noise_model_check` and `results/checks` was recomputed by the script named above and is identical to the table here (the clustering sweep of the monomodal and bimodal samples fully for Method D and NNLS, for the regularized fit at s = 0; the run-time columns of `checks/fast_regularized_fit.csv` depend on the machine). 155 stored tasks (all methods and settings, monomodal, bimodal and trimodal samples, s = 0, 1, 2) were re-run and agree with the stored per-file results (relative tolerance 1e-7).
- `run_study.py` asks Windows not to go to sleep while it runs (no effect on other systems).
